// Initialize the application when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
  // Set current year in footer
  document.getElementById('current-year').textContent = new Date().getFullYear();
  
  // Initialize all modules
  initTabs();
  initCustomers();
  initReservations();
  initOrders();
  initPayments();
  initOrderItems();
  initCafeItems();
  initBooks();
  initInventory();
  initToast();
  initModals();
});

// Tab Navigation
function initTabs() {
  const tabButtons = document.querySelectorAll('.tab-button');
  
  tabButtons.forEach(button => {
    button.addEventListener('click', () => {
      const tabName = button.getAttribute('data-tab');
      
      // Update active tab button
      tabButtons.forEach(btn => btn.classList.remove('active'));
      button.classList.add('active');
      
      // Update active tab content
      const tabContents = document.querySelectorAll('.tab-content');
      tabContents.forEach(content => content.classList.remove('active'));
      document.getElementById(`${tabName}-tab`).classList.add('active');
    });
  });
}

// Toast Notifications
function initToast() {
  const toast = document.getElementById('toast');
  const toastClose = document.querySelector('.toast-close');
  
  toastClose.addEventListener('click', () => {
    toast.classList.remove('active');
  });
  
  // Auto-hide toast after 5 seconds
  window.showToast = function(title, message) {
    document.getElementById('toast-title').textContent = title;
    document.getElementById('toast-message').textContent = message;
    toast.classList.add('active');
    
    setTimeout(() => {
      toast.classList.remove('active');
    }, 5000);
  };
}

// Modal Management
function initModals() {
  const modals = document.querySelectorAll('.modal');
  const closeButtons = document.querySelectorAll('.modal-close, .modal-cancel');
  
  // Close modal when clicking close button or cancel button
  closeButtons.forEach(button => {
    button.addEventListener('click', () => {
      const modal = button.closest('.modal');
      modal.classList.remove('active');
    });
  });
  
  // Close modal when clicking outside the modal content
  modals.forEach(modal => {
    modal.addEventListener('click', (e) => {
      if (e.target === modal) {
        modal.classList.remove('active');
      }
    });
  });
  
  // Open modal function
  window.openModal = function(modalId) {
    document.getElementById(modalId).classList.add('active');
  };
  
  // Close modal function
  window.closeModal = function(modalId) {
    document.getElementById(modalId).classList.remove('active');
  };
}

// Data Table Utilities
function createPagination(tableId, data, currentPage, itemsPerPage, renderFunction) {
  const paginationElement = document.getElementById(`${tableId}-pagination`);
  const totalPages = Math.ceil(data.length / itemsPerPage);
  
  if (totalPages <= 1) {
    paginationElement.innerHTML = '';
    return;
  }
  
  const startIndex = (currentPage - 1) * itemsPerPage;
  const endIndex = Math.min(startIndex + itemsPerPage, data.length);
  
  let paginationHTML = `
    <div class="pagination-info">
      Showing ${startIndex + 1}-${endIndex} of ${data.length}
    </div>
    <div class="pagination-controls">
      <button class="pagination-button" data-action="first" ${currentPage === 1 ? 'disabled' : ''}>
        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="11 17 6 12 11 7"></polyline><polyline points="18 17 13 12 18 7"></polyline></svg>
      </button>
      <button class="pagination-button" data-action="prev" ${currentPage === 1 ? 'disabled' : ''}>
        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="15 18 9 12 15 6"></polyline></svg>
      </button>
      <span class="pagination-current">Page ${currentPage} of ${totalPages}</span>
      <button class="pagination-button" data-action="next" ${currentPage === totalPages ? 'disabled' : ''}>
        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="9 18 15 12 9 6"></polyline></svg>
      </button>
      <button class="pagination-button" data-action="last" ${currentPage === totalPages ? 'disabled' : ''}>
        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="13 17 18 12 13 7"></polyline><polyline points="6 17 11 12 6 7"></polyline></svg>
      </button>
    </div>
  `;
  
  paginationElement.innerHTML = paginationHTML;
  
  // Add event listeners to pagination buttons
  const paginationButtons = paginationElement.querySelectorAll('.pagination-button');
  paginationButtons.forEach(button => {
    button.addEventListener('click', () => {
      const action = button.getAttribute('data-action');
      let newPage = currentPage;
      
      switch (action) {
        case 'first':
          newPage = 1;
          break;
        case 'prev':
          newPage = Math.max(1, currentPage - 1);
          break;
        case 'next':
          newPage = Math.min(totalPages, currentPage + 1);
          break;
        case 'last':
          newPage = totalPages;
          break;
      }
      
      if (newPage !== currentPage) {
        renderFunction(newPage);
      }
    });
  });
}

function filterData(data, searchTerm) {
  if (!searchTerm) return data;
  
  searchTerm = searchTerm.toLowerCase();
  
  return data.filter(item => {
    return Object.values(item).some(value => {
      if (value === null || value === undefined) return false;
      return value.toString().toLowerCase().includes(searchTerm);
    });
  });
}

// Format utilities
function formatCurrency(amount) {
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD'
  }).format(amount);
}

function formatDate(dateString) {
  if (!dateString) return '';
  return new Date(dateString).toLocaleDateString();
}

// Generate unique IDs
function generateId() {
  return Date.now().toString();
}

// Generate order/payment numbers
function generateOrderNumber() {
  const prefix = 'ORD-';
  const randomNum = Math.floor(100 + Math.random() * 900);
  return `${prefix}${randomNum}`;
}

function generatePaymentId() {
  const prefix = 'PAY-';
  const randomNum = Math.floor(100 + Math.random() * 900);
  return `${prefix}${randomNum}`;
}

// Status badges
function getStatusBadge(status, type) {
  let className = 'badge ';
  
  switch (type) {
    case 'reservation':
      if (status === 'confirmed') className += 'badge-success';
      else if (status === 'pending') className += 'badge-warning';
      else if (status === 'cancelled') className += 'badge-danger';
      else if (status === 'completed') className += 'badge-info';
      else className += 'badge-neutral';
      break;
      
    case 'order':
      if (status === 'completed') className += 'badge-success';
      else if (status === 'pending') className += 'badge-warning';
      else if (status === 'cancelled') className += 'badge-danger';
      else if (status === 'preparing') className += 'badge-info';
      else if (status === 'ready') className += 'badge-info';
      else className += 'badge-neutral';
      break;
      
    case 'payment':
      if (status === 'completed') className += 'badge-success';
      else if (status === 'pending') className += 'badge-warning';
      else if (status === 'failed') className += 'badge-danger';
      else if (status === 'refunded') className += 'badge-info';
      else className += 'badge-neutral';
      break;
      
    case 'orderItem':
      if (status === 'served') className += 'badge-success';
      else if (status === 'pending') className += 'badge-warning';
      else if (status === 'cancelled') className += 'badge-danger';
      else if (status === 'preparing') className += 'badge-info';
      else if (status === 'ready') className += 'badge-info';
      else className += 'badge-neutral';
      break;
      
    case 'availability':
      if (status === true) className += 'badge-success';
      else className += 'badge-danger';
      break;
      
    case 'condition':
      if (status === 'new') className += 'badge-success';
      else if (status === 'good') className += 'badge-info';
      else if (status === 'fair') className += 'badge-warning';
      else if (status === 'poor') className += 'badge-danger';
      else className += 'badge-neutral';
      break;
      
    case 'stock':
      if (status === 'in-stock') className += 'badge-success';
      else if (status === 'low-stock') className += 'badge-warning';
      else if (status === 'out-of-stock') className += 'badge-danger';
      else className += 'badge-neutral';
      break;
      
    case 'expiry':
      if (status === 'expired') className += 'badge-danger';
      else if (status === 'expiring-soon') className += 'badge-warning';
      else className += 'badge-neutral';
      break;
      
    default:
      className += 'badge-neutral';
  }
  
  const displayStatus = status.toString().charAt(0).toUpperCase() + status.toString().slice(1);
  
  if (type === 'availability') {
    return `<span class="${className}">${status ? 'Available' : 'Unavailable'}</span>`;
  } else if (type === 'stock') {
    let text = 'Unknown';
    if (status === 'in-stock') text = 'In Stock';
    else if (status === 'low-stock') text = 'Low Stock';
    else if (status === 'out-of-stock') text = 'Out of Stock';
    return `<span class="${className}">${text}</span>`;
  } else if (type === 'expiry') {
    let text = status;
    if (status === 'expired') {
      text = `<svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="margin-right: 4px;"><path d="m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3Z"></path><path d="M12 9v4"></path><path d="M12 17h.01"></path></svg> Expired`;
    } else if (status === 'expiring-soon') {
      text = `<svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="margin-right: 4px;"><path d="m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3Z"></path><path d="M12 9v4"></path><path d="M12 17h.01"></path></svg> Expiring Soon`;
    }
    return `<span class="${className}">${text}</span>`;
  }
  
  return `<span class="${className}">${displayStatus}</span>`;
}

// Form utilities
function getFormData(formId) {
  const form = document.getElementById(formId);
  const formData = new FormData(form);
  const data = {};
  
  formData.forEach((value, key) => {
    if (key === 'available') {
      data[key] = true; // Checkbox is checked
    } else {
      data[key] = value;
    }
  });
  
  // Handle unchecked checkboxes (not included in FormData)
  const checkboxes = form.querySelectorAll('input[type="checkbox"]');
  checkboxes.forEach(checkbox => {
    if (!checkbox.checked && !data.hasOwnProperty(checkbox.name)) {
      data[checkbox.name] = false;
    }
  });
  
  return data;
}

function fillFormData(formId, data) {
  const form = document.getElementById(formId);
  
  // Reset form first
  form.reset();
  
  // Fill form fields
  Object.keys(data).forEach(key => {
    const input = form.querySelector(`[name="${key}"]`);
    if (input) {
      if (input.type === 'checkbox') {
        input.checked = data[key];
        // Update switch label if exists
        const switchLabel = document.getElementById(`${formId.replace('form', '')}${key}-text`);
        if (switchLabel) {
          switchLabel.textContent = data[key] ? 'Available' : 'Unavailable';
        }
      } else {
        input.value = data[key];
      }
    }
  });
  
  // Set hidden ID field
  const idField = form.querySelector(`#${formId.replace('form', 'id')}`);
  if (idField && data.id) {
    idField.value = data.id;
  }
}

// Customers Module
function initCustomers() {
  let customers = [];
  let currentPage = 1;
  const itemsPerPage = 5;
  
  // Load data from localStorage
  function loadCustomers() {
    const savedCustomers = localStorage.getItem('cafe-customers');
    if (savedCustomers) {
      customers = JSON.parse(savedCustomers);
    } else {
      // Sample data
      customers = [
        {
          id: '1',
          name: 'John Smith',
          email: 'john@example.com',
          phone: '555-123-4567',
          joinDate: '2023-01-15',
          loyaltyPoints: 120
        },
        {
          id: '2',
          name: 'Sarah Johnson',
          email: 'sarah@example.com',
          phone: '555-987-6543',
          joinDate: '2023-03-22',
          loyaltyPoints: 85
        },
        {
          id: '3',
          name: 'Michael Brown',
          email: 'michael@example.com',
          phone: '555-456-7890',
          joinDate: '2023-05-10',
          loyaltyPoints: 45
        }
      ];
      saveCustomers();
    }
    renderCustomers();
  }
  
  // Save data to localStorage
  function saveCustomers() {
    localStorage.setItem('cafe-customers', JSON.stringify(customers));
  }
  
  // Render customers table
  function renderCustomers(page = 1) {
    currentPage = page;
    const tableBody = document.querySelector('#customers-table tbody');
    const searchTerm = document.getElementById('customers-search').value;
    const filteredCustomers = filterData(customers, searchTerm);
    
    // Calculate pagination
    const startIndex = (currentPage - 1) * itemsPerPage;
    const paginatedCustomers = filteredCustomers.slice(startIndex, startIndex + itemsPerPage);
    
    // Generate table rows
    let tableHTML = '';
    
    if (paginatedCustomers.length === 0) {
      tableHTML = `<tr><td colspan="6" class="text-center">No customers found.</td></tr>`;
    } else {
      paginatedCustomers.forEach(customer => {
        tableHTML += `
          <tr data-id="${customer.id}">
            <td>${customer.name}</td>
            <td>${customer.email}</td>
            <td>${customer.phone}</td>
            <td>${formatDate(customer.joinDate)}</td>
            <td>${customer.loyaltyPoints}</td>
            <td>
              <button class="btn secondary edit-customer" data-id="${customer.id}">
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17 3a2.85 2.83 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5Z"></path><path d="m15 5 4 4"></path></svg>
              </button>
              <button class="btn secondary delete-customer" data-id="${customer.id}">
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 6h18"></path><path d="M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"></path><path d="M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"></path></svg>
              </button>
            </td>
          </tr>
        `;
      });
    }
    
    tableBody.innerHTML = tableHTML;
    
    // Create pagination
    createPagination('customers', filteredCustomers, currentPage, itemsPerPage, renderCustomers);
    
    // Add event listeners to buttons
    document.querySelectorAll('.edit-customer').forEach(button => {
      button.addEventListener('click', (e) => {
        e.stopPropagation();
        const customerId = button.getAttribute('data-id');
        editCustomer(customerId);
      });
    });
    
    document.querySelectorAll('.delete-customer').forEach(button => {
      button.addEventListener('click', (e) => {
        e.stopPropagation();
        const customerId = button.getAttribute('data-id');
        deleteCustomer(customerId);
      });
    });
    
    // Add row click event for viewing
    document.querySelectorAll('#customers-table tbody tr').forEach(row => {
      row.addEventListener('click', () => {
        const customerId = row.getAttribute('data-id');
        viewCustomer(customerId);
      });
    });
  }
  
  // Add new customer
  function addCustomer() {
    document.getElementById('customer-modal-title').textContent = 'Add New Customer';
    document.getElementById('customer-form').reset();
    document.getElementById('customer-id').value = '';
    document.getElementById('customer-save').textContent = 'Add Customer';
    
    openModal('customer-modal');
  }
  
  // Edit customer
  function editCustomer(customerId) {
    const customer = customers.find(c => c.id === customerId);
    if (!customer) return;
    
    document.getElementById('customer-modal-title').textContent = 'Edit Customer';
    fillFormData('customer-form', customer);
    document.getElementById('customer-save').textContent = 'Save Changes';
    
    openModal('customer-modal');
  }
  
  // View customer details
  function viewCustomer(customerId) {
    const customer = customers.find(c => c.id === customerId);
    if (!customer) return;
    
    document.getElementById('view-modal-title').textContent = 'Customer Details';
    
    const content = `
      <div class="view-item">
        <div class="view-item-header">
          <div class="view-item-title">${customer.name}</div>
          <div class="view-item-subtitle">Customer since ${formatDate(customer.joinDate)}</div>
        </div>
        
        <div class="view-item-section">
          <div class="view-item-grid">
            <div>
              <div class="view-item-label">Email</div>
              <div class="view-item-value">${customer.email}</div>
            </div>
            <div>
              <div class="view-item-label">Phone</div>
              <div class="view-item-value">${customer.phone}</div>
            </div>
          </div>
        </div>
        
        <div class="view-item-section">
          <div>
            <div class="view-item-label">Loyalty Points</div>
            <div class="view-item-value">${customer.loyaltyPoints} points</div>
          </div>
        </div>
      </div>
    `;
    
    document.getElementById('view-modal-content').innerHTML = content;
    openModal('view-modal');
  }
  
  // Delete customer
  function deleteCustomer(customerId) {
    const customer = customers.find(c => c.id === customerId);
    if (!customer) return;
    
    document.getElementById('delete-message').textContent = `Are you sure you want to delete ${customer.name}? This action cannot be undone.`;
    
    const confirmDeleteBtn = document.getElementById('confirm-delete');
    confirmDeleteBtn.onclick = () => {
      customers = customers.filter(c => c.id !== customerId);
      saveCustomers();
      renderCustomers(currentPage);
      closeModal('delete-modal');
      showToast('Customer deleted', `${customer.name} has been removed.`);
    };
    
    openModal('delete-modal');
  }
  
  // Save customer (add or edit)
  function saveCustomer() {
    const formData = getFormData('customer-form');
    const customerId = document.getElementById('customer-id').value;
    
    if (customerId) {
      // Edit existing customer
      const index = customers.findIndex(c => c.id === customerId);
      if (index !== -1) {
        const updatedCustomer = {
          ...customers[index],
          name: formData.name,
          email: formData.email,
          phone: formData.phone,
          loyaltyPoints: parseInt(formData.loyaltyPoints) || 0
        };
        
        customers[index] = updatedCustomer;
        showToast('Customer updated', `${formData.name} has been updated successfully.`);
      }
    } else {
      // Add new customer
      const newCustomer = {
        id: generateId(),
        name: formData.name,
        email: formData.email,
        phone: formData.phone,
        joinDate: new Date().toISOString().split('T')[0],
        loyaltyPoints: parseInt(formData.loyaltyPoints) || 0
      };
      
      customers.push(newCustomer);
      showToast('Customer added', `${formData.name} has been added successfully.`);
    }
    
    saveCustomers();
    renderCustomers();
    closeModal('customer-modal');
  }
  
  // Initialize event listeners
  document.getElementById('add-customer-btn').addEventListener('click', addCustomer);
  document.getElementById('customer-save').addEventListener('click', saveCustomer);
  document.getElementById('customers-search').addEventListener('input', () => renderCustomers(1));
  
  // Load initial data
  loadCustomers();
}

// Reservations Module
function initReservations() {
  let reservations = [];
  let currentPage = 1;
  const itemsPerPage = 5;
  
  // Load data from localStorage
  function loadReservations() {
    const savedReservations = localStorage.getItem('cafe-reservations');
    if (savedReservations) {
      reservations = JSON.parse(savedReservations);
    } else {
      // Sample data
      const today = new Date().toISOString().split('T')[0];
      const tomorrow = new Date(Date.now() + 86400000).toISOString().split('T')[0];
      
      reservations = [
        {
          id: '1',
          customerName: 'John Smith',
          date: today,
          time: '18:30',
          partySize: 2,
          status: 'confirmed',
          specialRequests: 'Window seat preferred',
          contactNumber: '555-123-4567'
        },
        {
          id: '2',
          customerName: 'Sarah Johnson',
          date: tomorrow,
          time: '12:00',
          partySize: 4,
          status: 'pending',
          specialRequests: 'Birthday celebration',
          contactNumber: '555-987-6543'
        },
        {
          id: '3',
          customerName: 'Michael Brown',
          date: tomorrow,
          time: '19:00',
          partySize: 6,
          status: 'confirmed',
          specialRequests: '',
          contactNumber: '555-456-7890'
        }
      ];
      saveReservations();
    }
    renderReservations();
  }
  
  // Save data to localStorage
  function saveReservations() {
    localStorage.setItem('cafe-reservations', JSON.stringify(reservations));
  }
  
  // Render reservations table
  function renderReservations(page = 1) {
    currentPage = page;
    const tableBody = document.querySelector('#reservations-table tbody');
    const searchTerm = document.getElementById('reservations-search').value;
    const filteredReservations = filterData(reservations, searchTerm);
    
    // Calculate pagination
    const startIndex = (currentPage - 1) * itemsPerPage;
    const paginatedReservations = filteredReservations.slice(startIndex, startIndex + itemsPerPage);
    
    // Generate table rows
    let tableHTML = '';
    
    if (paginatedReservations.length === 0) {
      tableHTML = `<tr><td colspan="7" class="text-center">No reservations found.</td></tr>`;
    } else {
      paginatedReservations.forEach(reservation => {
        tableHTML += `
          <tr data-id="${reservation.id}">
            <td>${reservation.customerName}</td>
            <td>${formatDate(reservation.date)}</td>
            <td>${reservation.time}</td>
            <td>${reservation.partySize}</td>
            <td>${getStatusBadge(reservation.status, 'reservation')}</td>
            <td>${reservation.contactNumber}</td>
            <td>
              <button class="btn secondary edit-reservation" data-id="${reservation.id}">
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17 3a2.85 2.83 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5Z"></path><path d="m15 5 4 4"></path></svg>
              </button>
              <button class="btn secondary delete-reservation" data-id="${reservation.id}">
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 6h18"></path><path d="M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"></path><path d="M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"></path></svg>
              </button>
            </td>
          </tr>
        `;
      });
    }
    
    tableBody.innerHTML = tableHTML;
    
    // Create pagination
    createPagination('reservations', filteredReservations, currentPage, itemsPerPage, renderReservations);
    
    // Add event listeners to buttons
    document.querySelectorAll('.edit-reservation').forEach(button => {
      button.addEventListener('click', (e) => {
        e.stopPropagation();
        const reservationId = button.getAttribute('data-id');
        editReservation(reservationId);
      });
    });
    
    document.querySelectorAll('.delete-reservation').forEach(button => {
      button.addEventListener('click', (e) => {
        e.stopPropagation();
        const reservationId = button.getAttribute('data-id');
        deleteReservation(reservationId);
      });
    });
    
    // Add row click event for viewing
    document.querySelectorAll('#reservations-table tbody tr').forEach(row => {
      row.addEventListener('click', () => {
        const reservationId = row.getAttribute('data-id');
        viewReservation(reservationId);
      });
    });
  }
  
  // Add new reservation
  function addReservation() {
    document.getElementById('reservation-modal-title').textContent = 'Add New Reservation';
    document.getElementById('reservation-form').reset();
    document.getElementById('reservation-id').value = '';
    document.getElementById('reservation-date').value = new Date().toISOString().split('T')[0];
    document.getElementById('reservation-save').textContent = 'Add Reservation';
    
    openModal('reservation-modal');
  }
  
  // Edit reservation
  function editReservation(reservationId) {
    const reservation = reservations.find(r => r.id === reservationId);
    if (!reservation) return;
    
    document.getElementById('reservation-modal-title').textContent = 'Edit Reservation';
    fillFormData('reservation-form', reservation);
    document.getElementById('reservation-save').textContent = 'Save Changes';
    
    openModal('reservation-modal');
  }
  
  // View reservation details
  function viewReservation(reservationId) {
    const reservation = reservations.find(r => r.id === reservationId);
    if (!reservation) return;
    
    document.getElementById('view-modal-title').textContent = 'Reservation Details';
    
    const content = `
      <div class="view-item">
        <div class="view-item-header">
          <div class="view-item-title">Reservation for ${reservation.customerName}</div>
          <div class="view-item-subtitle">${formatDate(reservation.date)} at ${reservation.time}</div>
        </div>
        
        <div class="view-item-section">
          <div class="view-item-grid">
            <div>
              <div class="view-item-label">Party Size</div>
              <div class="view-item-value">${reservation.partySize} people</div>
            </div>
            <div>
              <div class="view-item-label">Status</div>
              <div class="view-item-value">${getStatusBadge(reservation.status, 'reservation')}</div>
            </div>
          </div>
        </div>
        
        <div class="view-item-section">
          <div>
            <div class="view-item-label">Contact Number</div>
            <div class="view-item-value">${reservation.contactNumber}</div>
          </div>
        </div>
        
        <div class="view-item-section">
          <div>
            <div class="view-item-label">Special Requests</div>
            <div class="view-item-value">${reservation.specialRequests || 'None'}</div>
          </div>
        </div>
      </div>
    `;
    
    document.getElementById('view-modal-content').innerHTML = content;
    openModal('view-modal');
  }
  
  // Delete reservation
  function deleteReservation(reservationId) {
    const reservation = reservations.find(r => r.id === reservationId);
    if (!reservation) return;
    
    document.getElementById('delete-message').textContent = `Are you sure you want to delete the reservation for ${reservation.customerName}? This action cannot be undone.`;
    
    const confirmDeleteBtn = document.getElementById('confirm-delete');
    confirmDeleteBtn.onclick = () => {
      reservations = reservations.filter(r => r.id !== reservationId);
      saveReservations();
      renderReservations(currentPage);
      closeModal('delete-modal');
      showToast('Reservation deleted', `Reservation for ${reservation.customerName} has been removed.`);
    };
    
    openModal('delete-modal');
  }
  
  // Save reservation (add or edit)
  function saveReservation() {
    const formData = getFormData('reservation-form');
    const reservationId = document.getElementById('reservation-id').value;
    
    if (reservationId) {
      // Edit existing reservation
      const index = reservations.findIndex(r => r.id === reservationId);
      if (index !== -1) {
        const updatedReservation = {
          ...reservations[index],
          customerName: formData.customerName,
          date: formData.date,
          time: formData.time,
          partySize: parseInt(formData.partySize) || 1,
          status: formData.status,
          specialRequests: formData.specialRequests,
          contactNumber: formData.contactNumber
        };
        
        reservations[index] = updatedReservation;
        showToast('Reservation updated', `Reservation for ${formData.customerName} has been updated successfully.`);
      }
    } else {
      // Add new reservation
      const newReservation = {
        id: generateId(),
        customerName: formData.customerName,
        date: formData.date,
        time: formData.time,
        partySize: parseInt(formData.partySize) || 1,
        status: formData.status,
        specialRequests: formData.specialRequests,
        contactNumber: formData.contactNumber
      };
      
      reservations.push(newReservation);
      showToast('Reservation added', `Reservation for ${formData.customerName} has been added successfully.`);
    }
    
    saveReservations();
    renderReservations();
    closeModal('reservation-modal');
  }
  
  // Initialize event listeners
  document.getElementById('add-reservation-btn').addEventListener('click', addReservation);
  document.getElementById('reservation-save').addEventListener('click', saveReservation);
  document.getElementById('reservations-search').addEventListener('input', () => renderReservations(1));
  
  // Load initial data
  loadReservations();
}

// Orders Module
function initOrders() {
  let orders = [];
  let currentPage = 1;
  const itemsPerPage = 5;
  
  // Load data from localStorage
  function loadOrders() {
    const savedOrders = localStorage.getItem('cafe-orders');
    if (savedOrders) {
      orders = JSON.parse(savedOrders);
    } else {
      // Sample data
      const today = new Date().toISOString().split('T')[0];
      const yesterday = new Date(Date.now() - 86400000).toISOString().split('T')[0];
      
      orders = [
        {
          id: '1',
          orderNumber: 'ORD-001',
          customerName: 'John Smith',
          date: today,
          time: '14:30',
          status: 'completed',
          total: 24.5,
          paymentStatus: 'paid',
          type: 'dine-in'
        },
        {
          id: '2',
          orderNumber: 'ORD-002',
          customerName: 'Sarah Johnson',
          date: today,
          time: '16:15',
          status: 'preparing',
          total: 18.75,
          paymentStatus: 'paid',
          type: 'takeaway'
        },
        {
          id: '3',
          orderNumber: 'ORD-003',
          customerName: 'Michael Brown',
          date: yesterday,
          time: '12:00',
          status: 'completed',
          total: 32.2,
          paymentStatus: 'paid',
          type: 'delivery'
        }
      ];
      saveOrders();
    }
    renderOrders();
  }
  
  // Save data to localStorage
  function saveOrders() {
    localStorage.setItem('cafe-orders', JSON.stringify(orders));
  }
  
  // Render orders table
  function renderOrders(page = 1) {
    currentPage = page;
    const tableBody = document.querySelector('#orders-table tbody');
    const searchTerm = document.getElementById('orders-search').value;
    const filteredOrders = filterData(orders, searchTerm);
    
    // Calculate pagination
    const startIndex = (currentPage - 1) * itemsPerPage;
    const paginatedOrders = filteredOrders.slice(startIndex, startIndex + itemsPerPage);
    
    // Generate table rows
    let tableHTML = '';
    
    if (paginatedOrders.length === 0) {
      tableHTML = `<tr><td colspan="8" class="text-center">No orders found.</td></tr>`;
    } else {
      paginatedOrders.forEach(order => {
        tableHTML += `
          <tr data-id="${order.id}">
            <td>${order.orderNumber}</td>
            <td>${order.customerName}</td>
            <td>${formatDate(order.date)} ${order.time}</td>
            <td>${getStatusBadge(order.status, 'order')}</td>
            <td>${formatCurrency(order.total)}</td>
            <td>${getStatusBadge(order.paymentStatus, 'payment')}</td>
            <td><span class="capitalize">${order.type}</span></td>
            <td>
              <button class="btn secondary view-order" data-id="${order.id}">
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M2 12s3-7 10-7 10 7 10 7-3 7-10 7-10-7-10-7Z"></path><circle cx="12" cy="12" r="3"></circle></svg>
              </button>
              <button class="btn secondary edit-order" data-id="${order.id}">
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17 3a2.85 2.83 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5Z"></path><path d="m15 5 4 4"></path></svg>
              </button>
              <button class="btn secondary delete-order" data-id="${order.id}">
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 6h18"></path><path d="M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"></path><path d="M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"></path></svg>
              </button>
            </td>
          </tr>
        `;
      });
    }
    
    tableBody.innerHTML = tableHTML;
    
    // Create pagination
    createPagination('orders', filteredOrders, currentPage, itemsPerPage, renderOrders);
    
    // Add event listeners to buttons
    document.querySelectorAll('.view-order').forEach(button => {
      button.addEventListener('click', (e) => {
        e.stopPropagation();
        const orderId = button.getAttribute('data-id');
        viewOrder(orderId);
      });
    });
    
    document.querySelectorAll('.edit-order').forEach(button => {
      button.addEventListener('click', (e) => {
        e.stopPropagation();
        const orderId = button.getAttribute('data-id');
        editOrder(orderId);
      });
    });
    
    document.querySelectorAll('.delete-order').forEach(button => {
      button.addEventListener('click', (e) => {
        e.stopPropagation();
        const orderId = button.getAttribute('data-id');
        deleteOrder(orderId);
      });
    });
    
    // Add row click event for viewing
    document.querySelectorAll('#orders-table tbody tr').forEach(row => {
      row.addEventListener('click', () => {
        const orderId = row.getAttribute('data-id');
        viewOrder(orderId);
      });
    });
  }
  
  // Add new order
  function addOrder() {
    document.getElementById('order-modal-title').textContent = 'Add New Order';
    document.getElementById('order-form').reset();
    document.getElementById('order-id').value = '';
    document.getElementById('order-number').value = generateOrderNumber();
    document.getElementById('order-save').textContent = 'Add Order';
    
    openModal('order-modal');
  }
  
  // Edit order
  function editOrder(orderId) {
    const order = orders.find(o => o.id === orderId);
    if (!order) return;
    
    document.getElementById('order-modal-title').textContent = 'Edit Order';
    fillFormData('order-form', order);
    document.getElementById('order-number').value = order.orderNumber;
    document.getElementById('order-save').textContent = 'Save Changes';
    
    openModal('order-modal');
  }
  
  // View order details
  function viewOrder(orderId) {
    const order = orders.find(o => o.id === orderId);
    if (!order) return;
    
    document.getElementById('view-modal-title').textContent = 'Order Details';
    
    const content = `
      <div class="view-item">
        <div class="view-item-header">
          <div class="view-item-title">Order #${order.orderNumber}</div>
          <div class="view-item-subtitle">${formatDate(order.date)} ${order.time}</div>
        </div>
        
        <div class="view-item-section">
          <div class="view-item-grid">
            <div>
              <div class="view-item-label">Customer</div>
              <div class="view-item-value">${order.customerName}</div>
            </div>
            <div>
              <div class="view-item-label">Type</div>
              <div class="view-item-value capitalize">${order.type}</div>
            </div>
          </div>
        </div>
        
        <div class="view-item-section">
          <div class="view-item-grid">
            <div>
              <div class="view-item-label">Status</div>
              <div class="view-item-value">${getStatusBadge(order.status, 'order')}</div>
            </div>
            <div>
              <div class="view-item-label">Payment</div>
              <div class="view-item-value">${getStatusBadge(order.paymentStatus, 'payment')}</div>
            </div>
          </div>
        </div>
        
        <div class="view-item-section">
          <div>
            <div class="view-item-label">Total Amount</div>
            <div class="view-item-value" style="font-size: 1.25rem; font-weight: 600;">${formatCurrency(order.total)}</div>
          </div>
        </div>
        
        <div class="view-item-section" style="border-top: 1px solid var(--border); padding-top: 1rem;">
          <div class="view-item-label">Note</div>
          <div class="view-item-value">Order items can be viewed in the Order Items section.</div>
        </div>
      </div>
    `;
    
    document.getElementById('view-modal-content').innerHTML = content;
    openModal('view-modal');
  }
  
  // Delete order
  function deleteOrder(orderId) {
    const order = orders.find(o => o.id === orderId);
    if (!order) return;
    
    document.getElementById('delete-message').textContent = `Are you sure you want to delete order #${order.orderNumber}? This action cannot be undone.`;
    
    const confirmDeleteBtn = document.getElementById('confirm-delete');
    confirmDeleteBtn.onclick = () => {
      orders = orders.filter(o => o.id !== orderId);
      saveOrders();
      renderOrders(currentPage);
      closeModal('delete-modal');
      showToast('Order deleted', `Order #${order.orderNumber} has been removed.`);
    };
    
    openModal('delete-modal');
  }
  
  // Save order (add or edit)
  function saveOrder() {
    const formData = getFormData('order-form');
    const orderId = document.getElementById('order-id').value;
    const orderNumber = document.getElementById('order-number').value;
    
    if (orderId) {
      // Edit existing order
      const index = orders.findIndex(o => o.id === orderId);
      if (index !== -1) {
        const updatedOrder = {
          ...orders[index],
          customerName: formData.customerName,
          status: formData.status,
          total: parseFloat(formData.total) || 0,
          paymentStatus: formData.paymentStatus,
          type: formData.type
        };
        
        orders[index] = updatedOrder;
        showToast('Order updated', `Order #${updatedOrder.orderNumber} has been updated successfully.`);
      }
    } else {
      // Add new order
      const now = new Date();
      const newOrder = {
        id: generateId(),
        orderNumber: orderNumber,
        customerName: formData.customerName,
        date: now.toISOString().split('T')[0],
        time: now.toTimeString().split(' ')[0].substring(0, 5),
        status: formData.status,
        total: parseFloat(formData.total) || 0,
        paymentStatus: formData.paymentStatus,
        type: formData.type
      };
      
      orders.push(newOrder);
      showToast('Order added', `Order #${newOrder.orderNumber} has been added successfully.`);
    }
    
    saveOrders();
    renderOrders();
    closeModal('order-modal');
  }
  
  // Initialize event listeners
  document.getElementById('add-order-btn').addEventListener('click', addOrder);
  document.getElementById('order-save').addEventListener('click', saveOrder);
  document.getElementById('orders-search').addEventListener('input', () => renderOrders(1));
  
  // Load initial data
  loadOrders();
}

// Payments Module
function initPayments() {
  let payments = [];
  let currentPage = 1;
  const itemsPerPage = 5;
  
  // Load data from localStorage
  function loadPayments() {
    const savedPayments = localStorage.getItem('cafe-payments');
    if (savedPayments) {
      payments = JSON.parse(savedPayments);
    } else {
      // Sample data
      const today = new Date().toISOString().split('T')[0];
      const yesterday = new Date(Date.now() - 86400000).toISOString().split('T')[0];
      
      payments = [
        {
          id: '1',
          paymentId: 'PAY-001',
          orderNumber: 'ORD-001',
          customerName: 'John Smith',
          date: today,
          amount: 24.5,
          method: 'credit_card',
          status: 'completed',
          reference: 'VISA **** 1234'
        },
        {
          id: '2',
          paymentId: 'PAY-002',
          orderNumber: 'ORD-002',
          customerName: 'Sarah Johnson',
          date: today,
          amount: 18.75,
          method: 'cash',
          status: 'completed',
          reference: ''
        },
        {
          id: '3',
          paymentId: 'PAY-003',
          orderNumber: 'ORD-003',
          customerName: 'Michael Brown',
          date: yesterday,
          amount: 32.2,
          method: 'mobile_payment',
          status: 'completed',
          reference: 'Apple Pay'
        }
      ];
      savePayments();
    }
    renderPayments();
  }
  
  // Save data to localStorage
  function savePayments() {
    localStorage.setItem('cafe-payments', JSON.stringify(payments));
  }
  
  // Render payments table
  function renderPayments(page = 1) {
    currentPage = page;
    const tableBody = document.querySelector('#payments-table tbody');
    const searchTerm = document.getElementById('payments-search').value;
    const filteredPayments = filterData(payments, searchTerm);
    
    // Calculate pagination
    const startIndex = (currentPage - 1) * itemsPerPage;
    const paginatedPayments = filteredPayments.slice(startIndex, startIndex + itemsPerPage);
    
    // Generate table rows
    let tableHTML = '';
    
    if (paginatedPayments.length === 0) {
      tableHTML = `<tr><td colspan="8" class="text-center">No payments found.</td></tr>`;
    } else {
      paginatedPayments.forEach(payment => {
        tableHTML += `
          <tr data-id="${payment.id}">
            <td>${payment.paymentId}</td>
            <td>${payment.orderNumber}</td>
            <td>${payment.customerName}</td>
            <td>${formatDate(payment.date)}</td>
            <td>${formatCurrency(payment.amount)}</td>
            <td>${getMethodLabel(payment.method)}</td>
            <td>${getStatusBadge(payment.status, 'payment')}</td>
            <td>
              <button class="btn secondary view-payment" data-id="${payment.id}">
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 22h16a2 2 0 0 0 2-2V4a2 2 0 0 0-2-2H8a2 2 0 0 0-2 2v16a2 2 0 0 1-2 2Zm0 0a2 2 0 0 1-2-2v-9c0-1.1.9-2 2-2h2"></path><path d="M18 14h-8"></path><path d="M15 18h-5"></path><path d="M10 6h8v4h-8V6Z"></path></svg>
              </button>
              <button class="btn secondary edit-payment" data-id="${payment.id}">
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17 3a2.85 2.83 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5Z"></path><path d="m15 5 4 4"></path></svg>
              </button>
              <button class="btn secondary delete-payment" data-id="${payment.id}">
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 6h18"></path><path d="M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"></path><path d="M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"></path></svg>
              </button>
            </td>
          </tr>
        `;
      });
    }
    
    tableBody.innerHTML = tableHTML;
    
    // Create pagination
    createPagination('payments', filteredPayments, currentPage, itemsPerPage, renderPayments);
    
    // Add event listeners to buttons
    document.querySelectorAll('.view-payment').forEach(button => {
      button.addEventListener('click', (e) => {
        e.stopPropagation();
        const paymentId = button.getAttribute('data-id');
        viewPayment(paymentId);
      });
    });
    
    document.querySelectorAll('.edit-payment').forEach(button => {
      button.addEventListener('click', (e) => {
        e.stopPropagation();
        const paymentId = button.getAttribute('data-id');
        editPayment(paymentId);
      });
    });
    
    document.querySelectorAll('.delete-payment').forEach(button => {
      button.addEventListener('click', (e) => {
        e.stopPropagation();
        const paymentId = button.getAttribute('data-id');
        deletePayment(paymentId);
      });
    });
    
    // Add row click event for viewing
    document.querySelectorAll('#payments-table tbody tr').forEach(row => {
      row.addEventListener('click', () => {
        const paymentId = row.getAttribute('data-id');
        viewPayment(paymentId);
      });
    });
  }
  
  // Get method label
  function getMethodLabel(method) {
    const methodLabels = {
      cash: 'Cash',
      credit_card: 'Credit Card',
      debit_card: 'Debit Card',
      mobile_payment: 'Mobile Payment',
      gift_card: 'Gift Card'
    };
    
    return methodLabels[method] || method;
  }
  
  // Add new payment
  function addPayment() {
    document.getElementById('payment-modal-title').textContent = 'Add New Payment';
    document.getElementById('payment-form').reset();
    document.getElementById('payment-id').value = '';
    document.getElementById('payment-payment-id').value = generatePaymentId();
    document.getElementById('payment-save').textContent = 'Add Payment';
    
    openModal('payment-modal');
  }
  
  // Edit payment
  function editPayment(paymentId) {
    const payment = payments.find(p => p.id === paymentId);
    if (!payment) return;
    
    document.getElementById('payment-modal-title').textContent = 'Edit Payment';
    fillFormData('payment-form', payment);
    document.getElementById('payment-payment-id').value = payment.paymentId;
    document.getElementById('payment-save').textContent = 'Save Changes';
    
    openModal('payment-modal');
  }
  
  // View payment details (receipt)
  function viewPayment(paymentId) {
    const payment = payments.find(p => p.id === paymentId);
    if (!payment) return;
    
    document.getElementById('view-modal-title').textContent = 'Payment Receipt';
    
    const content = `
    <div class="view-item">
        <div class="view-item-header" style="text-align: center; margin-bottom: 1rem;">
          <div class="view-item-title">Café Receipt</div>
          <div class="view-item-subtitle">Thank you for your visit!</div>
        </div>
        
        <div class="view-item-section">
          <div class="view-item-grid">
            <div>
              <div class="view-item-label">Payment ID:</div>
              <div class="view-item-value">${payment.paymentId}</div>
            </div>
            <div>
              <div class="view-item-label">Order Number:</div>
              <div class="view-item-value">${payment.orderNumber}</div>
            </div>
          </div>
          
          <div class="view-item-grid" style="margin-top: 0.5rem;">
            <div>
              <div class="view-item-label">Date:</div>
              <div class="view-item-value">${formatDate(payment.date)}</div>
            </div>
            <div>
              <div class="view-item-label">Customer:</div>
              <div class="view-item-value">${payment.customerName}</div>
            </div>
          </div>
          
          <div class="view-item-grid" style="margin-top: 0.5rem;">
            <div>
              <div class="view-item-label">Payment Method:</div>
              <div class="view-item-value">${getMethodLabel(payment.method)}</div>
            </div>
            ${payment.reference ? `
            <div>
              <div class="view-item-label">Reference:</div>
              <div class="view-item-value">${payment.reference}</div>
            </div>
            ` : ''}
          </div>
          
          <div style="margin-top: 1rem; padding-top: 1rem; border-top: 1px solid var(--border);">
            <div class="view-item-grid">
              <div>
                <div class="view-item-label" style="font-weight: 600;">Total Amount:</div>
              </div>
              <div>
                <div class="view-item-value" style="font-weight: 600; font-size: 1.125rem;">${formatCurrency(payment.amount)}</div>
              </div>
            </div>
          </div>
        </div>
        
        <div class="view-item-section" style="text-align: center; margin-top: 1rem; padding-top: 1rem; border-top: 1px solid var(--border); color: var(--text-light); font-size: 0.875rem;">
          <p>This is a digital receipt.</p>
          <p>Thank you for choosing our café!</p>
        </div>
      </div>
    `;
    
    document.getElementById('view-modal-content').innerHTML = content;
    openModal('view-modal');
  }
  
  // Delete payment
  function deletePayment(paymentId) {
    const payment = payments.find(p => p.id === paymentId);
    if (!payment) return;
    
    document.getElementById('delete-message').textContent = `Are you sure you want to delete payment #${payment.paymentId}? This action cannot be undone.`;
    
    const confirmDeleteBtn = document.getElementById('confirm-delete');
    confirmDeleteBtn.onclick = () => {
      payments = payments.filter(p => p.id !== paymentId);
      savePayments();
      renderPayments(currentPage);
      closeModal('delete-modal');
      showToast('Payment deleted', `Payment #${payment.paymentId} has been removed.`);
    };
    
    openModal('delete-modal');
  }
  
  // Save payment (add or edit)
  function savePayment() {
    const formData = getFormData('payment-form');
    const paymentId = document.getElementById('payment-id').value;
    const paymentPaymentId = document.getElementById('payment-payment-id').value;
    
    if (paymentId) {
      // Edit existing payment
      const index = payments.findIndex(p => p.id === paymentId);
      if (index !== -1) {
        const updatedPayment = {
          ...payments[index],
          orderNumber: formData.orderNumber,
          customerName: formData.customerName,
          amount: parseFloat(formData.amount) || 0,
          method: formData.method,
          status: formData.status,
          reference: formData.reference
        };
        
        payments[index] = updatedPayment;
        showToast('Payment updated', `Payment #${updatedPayment.paymentId} has been updated successfully.`);
      }
    } else {
      // Add new payment
      const newPayment = {
        id: generateId(),
        paymentId: paymentPaymentId,
        orderNumber: formData.orderNumber,
        customerName: formData.customerName,
        date: new Date().toISOString().split('T')[0],
        amount: parseFloat(formData.amount) || 0,
        method: formData.method,
        status: formData.status,
        reference: formData.reference
      };
      
      payments.push(newPayment);
      showToast('Payment added', `Payment #${newPayment.paymentId} has been added successfully.`);
    }
    
    savePayments();
    renderPayments();
    closeModal('payment-modal');
  }
  
  // Initialize event listeners
  document.getElementById('add-payment-btn').addEventListener('click', addPayment);
  document.getElementById('payment-save').addEventListener('click', savePayment);
  document.getElementById('payments-search').addEventListener('input', () => renderPayments(1));
  
  // Load initial data
  loadPayments();
}

// Order Items Module
function initOrderItems() {
  let orderItems = [];
  let currentPage = 1;
  const itemsPerPage = 5;
  
  // Load data from localStorage
  function loadOrderItems() {
    const savedOrderItems = localStorage.getItem('cafe-order-items');
    if (savedOrderItems) {
      orderItems = JSON.parse(savedOrderItems);
    } else {
      // Sample data
      orderItems = [
        {
          id: '1',
          orderNumber: 'ORD-001',
          itemName: 'Cappuccino',
          quantity: 2,
          unitPrice: 4.5,
          totalPrice: 9.0,
          notes: 'Extra foam',
          status: 'served'
        },
        {
          id: '2',
          orderNumber: 'ORD-001',
          itemName: 'Chocolate Croissant',
          quantity: 1,
          unitPrice: 3.75,
          totalPrice: 3.75,
          notes: '',
          status: 'served'
        },
        {
          id: '3',
          orderNumber: 'ORD-002',
          itemName: 'Iced Latte',
          quantity: 1,
          unitPrice: 5.25,
          totalPrice: 5.25,
          notes: 'Almond milk',
          status: 'preparing'
        },
        {
          id: '4',
          orderNumber: 'ORD-002',
          itemName: 'Blueberry Muffin',
          quantity: 2,
          unitPrice: 3.5,
          totalPrice: 7.0,
          notes: '',
          status: 'ready'
        }
      ];
      saveOrderItems();
    }
    renderOrderItems();
    
    // Add event listeners for calculating total price
    const quantityInput = document.getElementById('orderItem-quantity');
    const priceInput = document.getElementById('orderItem-price');
    
    function updateTotalPrice() {
      const quantity = parseInt(quantityInput.value) || 0;
      const price = parseFloat(priceInput.value) || 0;
      const total = quantity * price;
      document.getElementById('orderItem-total').textContent = formatCurrency(total);
    }
    
    quantityInput.addEventListener('input', updateTotalPrice);
    priceInput.addEventListener('input', updateTotalPrice);
  }
  
  // Save data to localStorage
  function saveOrderItems() {
    localStorage.setItem('cafe-order-items', JSON.stringify(orderItems));
  }
  
  // Render order items table
  function renderOrderItems(page = 1) {
    currentPage = page;
    const tableBody = document.querySelector('#orderItems-table tbody');
    const searchTerm = document.getElementById('orderItems-search').value;
    const filteredOrderItems = filterData(orderItems, searchTerm);
    
    // Calculate pagination
    const startIndex = (currentPage - 1) * itemsPerPage;
    const paginatedOrderItems = filteredOrderItems.slice(startIndex, startIndex + itemsPerPage);
    
    // Generate table rows
    let tableHTML = '';
    
    if (paginatedOrderItems.length === 0) {
      tableHTML = `<tr><td colspan="7" class="text-center">No order items found.</td></tr>`;
    } else {
      paginatedOrderItems.forEach(item => {
        tableHTML += `
          <tr data-id="${item.id}">
            <td>${item.orderNumber}</td>
            <td>${item.itemName}</td>
            <td>${item.quantity}</td>
            <td>${formatCurrency(item.unitPrice)}</td>
            <td>${formatCurrency(item.totalPrice)}</td>
            <td>${getStatusBadge(item.status, 'orderItem')}</td>
            <td>
              <button class="btn secondary edit-orderItem" data-id="${item.id}">
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17 3a2.85 2.83 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5Z"></path><path d="m15 5 4 4"></path></svg>
              </button>
              <button class="btn secondary delete-orderItem" data-id="${item.id}">
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 6h18"></path><path d="M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"></path><path d="M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"></path></svg>
              </button>
            </td>
          </tr>
        `;
      });
    }
    
    tableBody.innerHTML = tableHTML;
    
    // Create pagination
    createPagination('orderItems', filteredOrderItems, currentPage, itemsPerPage, renderOrderItems);
    
    // Add event listeners to buttons
    document.querySelectorAll('.edit-orderItem').forEach(button => {
      button.addEventListener('click', (e) => {
        e.stopPropagation();
        const orderItemId = button.getAttribute('data-id');
        editOrderItem(orderItemId);
      });
    });
    
    document.querySelectorAll('.delete-orderItem').forEach(button => {
      button.addEventListener('click', (e) => {
        e.stopPropagation();
        const orderItemId = button.getAttribute('data-id');
        deleteOrderItem(orderItemId);
      });
    });
    
    // Add row click event for editing
    document.querySelectorAll('#orderItems-table tbody tr').forEach(row => {
      row.addEventListener('click', () => {
        const orderItemId = row.getAttribute('data-id');
        editOrderItem(orderItemId);
      });
    });
  }
  
  // Calculate total price
  function calculateTotalPrice(quantity, unitPrice) {
    return quantity * unitPrice;
  }
  
  // Add new order item
  function addOrderItem() {
    document.getElementById('orderItem-modal-title').textContent = 'Add New Order Item';
    document.getElementById('orderItem-form').reset();
    document.getElementById('orderItem-id').value = '';
    document.getElementById('orderItem-total').textContent = '$0.00';
    document.getElementById('orderItem-save').textContent = 'Add Item';
    
    openModal('orderItem-modal');
  }
  
  // Edit order item
  function editOrderItem(orderItemId) {
    const orderItem = orderItems.find(item => item.id === orderItemId);
    if (!orderItem) return;
    
    document.getElementById('orderItem-modal-title').textContent = 'Edit Order Item';
    fillFormData('orderItem-form', orderItem);
    document.getElementById('orderItem-total').textContent = formatCurrency(orderItem.totalPrice);
    document.getElementById('orderItem-save').textContent = 'Save Changes';
    
    openModal('orderItem-modal');
  }
  
  // Delete order item
  function deleteOrderItem(orderItemId) {
    const orderItem = orderItems.find(item => item.id === orderItemId);
    if (!orderItem) return;
    
    document.getElementById('delete-message').textContent = `Are you sure you want to delete ${orderItem.quantity}x ${orderItem.itemName}? This action cannot be undone.`;
    
    const confirmDeleteBtn = document.getElementById('confirm-delete');
    confirmDeleteBtn.onclick = () => {
      orderItems = orderItems.filter(item => item.id !== orderItemId);
      saveOrderItems();
      renderOrderItems(currentPage);
      closeModal('delete-modal');
      showToast('Order item deleted', `${orderItem.quantity}x ${orderItem.itemName} has been removed.`);
    };
    
    openModal('delete-modal');
  }
  
  // Save order item (add or edit)
  function saveOrderItem() {
    const formData = getFormData('orderItem-form');
    const orderItemId = document.getElementById('orderItem-id').value;
    
    const quantity = parseInt(formData.quantity) || 1;
    const unitPrice = parseFloat(formData.unitPrice) || 0;
    const totalPrice = calculateTotalPrice(quantity, unitPrice);
    
    if (orderItemId) {
      // Edit existing order item
      const index = orderItems.findIndex(item => item.id === orderItemId);
      if (index !== -1) {
        const updatedOrderItem = {
          ...orderItems[index],
          orderNumber: formData.orderNumber,
          itemName: formData.itemName,
          quantity: quantity,
          unitPrice: unitPrice,
          totalPrice: parseFloat(totalPrice.toFixed(2)),
          notes: formData.notes,
          status: formData.status
        };
        
        orderItems[index] = updatedOrderItem;
        showToast('Order item updated', `${quantity}x ${formData.itemName} has been updated.`);
      }
    } else {
      // Add new order item
      const newOrderItem = {
        id: generateId(),
        orderNumber: formData.orderNumber,
        itemName: formData.itemName,
        quantity: quantity,
        unitPrice: unitPrice,
        totalPrice: parseFloat(totalPrice.toFixed(2)),
        notes: formData.notes,
        status: formData.status
      };
      
      orderItems.push(newOrderItem);
      showToast('Order item added', `${quantity}x ${formData.itemName} added to order #${formData.orderNumber}.`);
    }
    
    saveOrderItems();
    renderOrderItems();
    closeModal('orderItem-modal');
  }
  
  // Initialize event listeners
  document.getElementById('add-orderItem-btn').addEventListener('click', addOrderItem);
  document.getElementById('orderItem-save').addEventListener('click', saveOrderItem);
  document.getElementById('orderItems-search').addEventListener('input', () => renderOrderItems(1));
  
  // Load initial data
  loadOrderItems();
}

// Cafe Items Module
function initCafeItems() {
  let cafeItems = [];
  let currentPage = 1;
  const itemsPerPage = 5;
  
  // Load data from localStorage
  function loadCafeItems() {
    const savedCafeItems = localStorage.getItem('cafe-items');
    if (savedCafeItems) {
      cafeItems = JSON.parse(savedCafeItems);
    } else {
      // Sample data
      cafeItems = [
        {
          id: '1',
          name: 'Cappuccino',
          category: 'coffee',
          price: 4.5,
          description: 'Espresso with steamed milk and a deep layer of foam',
          available: true,
          ingredients: 'Espresso, Milk',
          allergens: 'Milk'
        },
        {
          id: '2',
          name: 'Earl Grey Tea',
          category: 'tea',
          price: 3.75,
          description: 'Black tea flavored with oil of bergamot',
          available: true,
          ingredients: 'Black tea, Bergamot oil',
          allergens: 'None'
        },
        {
          id: '3',
          name: 'Chocolate Croissant',
          category: 'pastry',
          price: 3.95,
          description: 'Buttery croissant filled with chocolate',
          available: true,
          ingredients: 'Flour, Butter, Chocolate, Sugar, Yeast',
          allergens: 'Wheat, Dairy, May contain traces of nuts'
        },
        {
          id: '4',
          name: 'Avocado Toast',
          category: 'sandwich',
          price: 8.5,
          description: 'Sourdough toast topped with avocado, cherry tomatoes, and microgreens',
          available: true,
          ingredients: 'Sourdough bread, Avocado, Cherry tomatoes, Olive oil, Salt, Microgreens',
          allergens: 'Wheat'
        }
      ];
      saveCafeItems();
    }
    renderCafeItems();
    
    // Add event listener for availability switch
    const availableSwitch = document.getElementById('cafeItem-available');
    const availableText = document.getElementById('cafeItem-available-text');
    
    if (availableSwitch && availableText) {
      availableSwitch.addEventListener('change', function() {
        availableText.textContent = this.checked ? 'Available' : 'Unavailable';
      });
    }
  }
  
  // Save data to localStorage
  function saveCafeItems() {
    localStorage.setItem('cafe-items', JSON.stringify(cafeItems));
  }
  
  // Get category label
  function getCategoryLabel(category) {
    const categoryLabels = {
      coffee: 'Coffee',
      tea: 'Tea',
      pastry: 'Pastry',
      sandwich: 'Sandwich',
      dessert: 'Dessert',
      other: 'Other'
    };
    
    return categoryLabels[category] || category;
  }
  
  // Render cafe items table
  function renderCafeItems(page = 1) {
    currentPage = page;
    const tableBody = document.querySelector('#cafeItems-table tbody');
    const searchTerm = document.getElementById('cafeItems-search').value;
    const filteredCafeItems = filterData(cafeItems, searchTerm);
    
    // Calculate pagination
    const startIndex = (currentPage - 1) * itemsPerPage;
    const paginatedCafeItems = filteredCafeItems.slice(startIndex, startIndex + itemsPerPage);
    
    // Generate table rows
    let tableHTML = '';
    
    if (paginatedCafeItems.length === 0) {
      tableHTML = `<tr><td colspan="5" class="text-center">No menu items found.</td></tr>`;
    } else {
      paginatedCafeItems.forEach(item => {
        tableHTML += `
          <tr data-id="${item.id}">
            <td>${item.name}</td>
            <td>${getCategoryLabel(item.category)}</td>
            <td>${formatCurrency(item.price)}</td>
            <td>${getStatusBadge(item.available, 'availability')}</td>
            <td>
              <button class="btn secondary view-cafeItem" data-id="${item.id}">
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M2 12s3-7 10-7 10 7 10 7-3 7-10 7-10-7-10-7Z"></path><circle cx="12" cy="12" r="3"></circle></svg>
              </button>
              <button class="btn secondary edit-cafeItem" data-id="${item.id}">
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17 3a2.85 2.83 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5Z"></path><path d="m15 5 4 4"></path></svg>
              </button>
              <button class="btn secondary delete-cafeItem" data-id="${item.id}">
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 6h18"></path><path d="M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"></path><path d="M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"></path></svg>
              </button>
            </td>
          </tr>
        `;
      });
    }
    
    tableBody.innerHTML = tableHTML;
    
    // Create pagination
    createPagination('cafeItems', filteredCafeItems, currentPage, itemsPerPage, renderCafeItems);
    
    // Add event listeners to buttons
    document.querySelectorAll('.view-cafeItem').forEach(button => {
      button.addEventListener('click', (e) => {
        e.stopPropagation();
        const cafeItemId = button.getAttribute('data-id');
        viewCafeItem(cafeItemId);
      });
    });
    
    document.querySelectorAll('.edit-cafeItem').forEach(button => {
      button.addEventListener('click', (e) => {
        e.stopPropagation();
        const cafeItemId = button.getAttribute('data-id');
        editCafeItem(cafeItemId);
      });
    });
    
    document.querySelectorAll('.delete-cafeItem').forEach(button => {
      button.addEventListener('click', (e) => {
        e.stopPropagation();
        const cafeItemId = button.getAttribute('data-id');
        deleteCafeItem(cafeItemId);
      });
    });
    
    // Add row click event for viewing
    document.querySelectorAll('#cafeItems-table tbody tr').forEach(row => {
      row.addEventListener('click', () => {
        const cafeItemId = row.getAttribute('data-id');
        viewCafeItem(cafeItemId);
      });
    });
  }
  
  // Add new cafe item
  function addCafeItem() {
    document.getElementById('cafeItem-modal-title').textContent = 'Add New Menu Item';
    document.getElementById('cafeItem-form').reset();
    document.getElementById('cafeItem-id').value = '';
    document.getElementById('cafeItem-available').checked = true;
    document.getElementById('cafeItem-available-text').textContent = 'Available';
    document.getElementById('cafeItem-save').textContent = 'Add Item';
    
    openModal('cafeItem-modal');
  }
  
  // Edit cafe item
  function editCafeItem(cafeItemId) {
    const cafeItem = cafeItems.find(item => item.id === cafeItemId);
    if (!cafeItem) return;
    
    document.getElementById('cafeItem-modal-title').textContent = 'Edit Menu Item';
    fillFormData('cafeItem-form', cafeItem);
    document.getElementById('cafeItem-available-text').textContent = cafeItem.available ? 'Available' : 'Unavailable';
    document.getElementById('cafeItem-save').textContent = 'Save Changes';
    
    openModal('cafeItem-modal');
  }
  
  // View cafe item details
  function viewCafeItem(cafeItemId) {
    const cafeItem = cafeItems.find(item => item.id === cafeItemId);
    if (!cafeItem) return;
    
    document.getElementById('view-modal-title').textContent = 'Menu Item Details';
    
    const content = `
      <div class="view-item">
        <div class="view-item-header">
          <div class="view-item-title">${cafeItem.name}</div>
          <div class="view-item-subtitle">
            ${getCategoryLabel(cafeItem.category)} • ${formatCurrency(cafeItem.price)}
          </div>
        </div>
        
        <div class="view-item-grid">
          <div class="view-item-section">
            <div>
              <div class="view-item-label">Description</div>
              <div class="view-item-value">${cafeItem.description}</div>
            </div>
            
            <div style="margin-top: 1rem;">
              <div class="view-item-label">Ingredients</div>
              <div class="view-item-value">${cafeItem.ingredients}</div>
            </div>
            
            <div style="margin-top: 1rem;">
              <div class="view-item-label">Allergens</div>
              <div class="view-item-value">${cafeItem.allergens || 'None listed'}</div>
            </div>
            
            <div style="margin-top: 1rem;">
              <div class="view-item-label">Availability</div>
              <div class="view-item-value">${getStatusBadge(cafeItem.available, 'availability')}</div>
            </div>
          </div>
          
          <div class="view-item-image">
            ${cafeItem.image ? `
              <img src="${cafeItem.image}" alt="${cafeItem.name}" />
            ` : `
              <div class="view-item-no-image">No image available</div>
            `}
          </div>
        </div>
      </div>
    `;
    
    document.getElementById('view-modal-content').innerHTML = content;
    openModal('view-modal');
  }
  
  // Delete cafe item
  function deleteCafeItem(cafeItemId) {
    const cafeItem = cafeItems.find(item => item.id === cafeItemId);
    if (!cafeItem) return;
    
    document.getElementById('delete-message').textContent = `Are you sure you want to delete ${cafeItem.name} from the menu? This action cannot be undone.`;
    
    const confirmDeleteBtn = document.getElementById('confirm-delete');
    confirmDeleteBtn.onclick = () => {
      cafeItems = cafeItems.filter(item => item.id !== cafeItemId);
      saveCafeItems();
      renderCafeItems(currentPage);
      closeModal('delete-modal');
      showToast('Menu item deleted', `${cafeItem.name} has been removed from the menu.`);
    };
    
    openModal('delete-modal');
  }
  
  // Save cafe item (add or edit)
  function saveMenuItem() {
    const formData = getFormData('cafeItem-form');
    const cafeItemId = document.getElementById('cafeItem-id').value;
    
    if (cafeItemId) {
      // Edit existing cafe item
      const index = cafeItems.findIndex(item => item.id === cafeItemId);
      if (index !== -1) {
        const updatedCafeItem = {
          ...cafeItems[index],
          name: formData.name,
          category: formData.category,
          price: parseFloat(formData.price) || 0,
          description: formData.description,
          available: formData.available,
          ingredients: formData.ingredients,
          allergens: formData.allergens,
          image: formData.image || undefined
        };
        
        cafeItems[index] = updatedCafeItem;
        showToast('Menu item updated', `${formData.name} has been updated.`);
      }
    } else {
      // Add new cafe item
      const newCafeItem = {
        id: generateId(),
        name: formData.name,
        category: formData.category,
        price: parseFloat(formData.price) || 0,
        description: formData.description,
        available: formData.available,
        ingredients: formData.ingredients,
        allergens: formData.allergens,
        image: formData.image || undefined
      };
      
      cafeItems.push(newCafeItem);
      showToast('Menu item added', `${formData.name} has been added to the menu.`);
    }
    
    saveCafeItems();
    renderCafeItems();
    closeModal('cafeItem-modal');
  }
  
  // Initialize event listeners
  document.getElementById('add-cafeItem-btn').addEventListener('click', addCafeItem);
  document.getElementById('cafeItem-save').addEventListener('click', saveMenuItem);
  document.getElementById('cafeItems-search').addEventListener('input', () => renderCafeItems(1));
  
  // Load initial data
  loadCafeItems();
}

// Books Module
function initBooks() {
  let books = [];
  let currentPage = 1;
  const itemsPerPage = 5;
  
  // Load data from localStorage
  function loadBooks() {
    const savedBooks = localStorage.getItem('cafe-books');
    if (savedBooks) {
      books = JSON.parse(savedBooks);
    } else {
      // Sample data
      books = [
        {
          id: '1',
          title: 'The Midnight Library',
          author: 'Matt Haig',
          genre: 'Fiction',
          description: 'Between life and death there is a library, and within that library, the shelves go on forever.',
          available: true,
          condition: 'new',
          location: 'Shelf A1'
        },
        {
          id: '2',
          title: 'Atomic Habits',
          author: 'James Clear',
          genre: 'Self-Help',
          description: 'An easy and proven way to build good habits and break bad ones.',
          available: true,
          condition: 'good',
          location: 'Shelf B2'
        },
        {
          id: '3',
          title: 'The Art of Coffee',
          author: 'Jane Smith',
          genre: 'Food & Drink',
          description: 'A comprehensive guide to brewing the perfect cup of coffee.',
          available: false,
          condition: 'fair',
          location: 'Shelf C3'
        }
      ];
      saveBooks();
    }
    renderBooks();
    
    // Add event listener for availability switch
    const availableSwitch = document.getElementById('book-available');
    const availableText = document.getElementById('book-available-text');
    
    if (availableSwitch && availableText) {
      availableSwitch.addEventListener('change', function() {
        availableText.textContent = this.checked ? 'Available' : 'Checked Out';
      });
    }
  }
  
  // Save data to localStorage
  function saveBooks() {
    localStorage.setItem('cafe-books', JSON.stringify(books));
  }
  
  // Render books table
  function renderBooks(page = 1) {
    currentPage = page;
    const tableBody = document.querySelector('#books-table tbody');
    const searchTerm = document.getElementById('books-search').value;
    const filteredBooks = filterData(books, searchTerm);
    
    // Calculate pagination
    const startIndex = (currentPage - 1) * itemsPerPage;
    const paginatedBooks = filteredBooks.slice(startIndex, startIndex + itemsPerPage);
    
    // Generate table rows
    let tableHTML = '';
    
    if (paginatedBooks.length === 0) {
      tableHTML = `<tr><td colspan="7" class="text-center">No books found.</td></tr>`;
    } else {
      paginatedBooks.forEach(book => {
        tableHTML += `
          <tr data-id="${book.id}">
            <td>${book.title}</td>
            <td>${book.author}</td>
            <td>${book.genre}</td>
            <td>${getStatusBadge(book.condition, 'condition')}</td>
            <td>${getStatusBadge(book.available, 'availability')}</td>
            <td>${book.location}</td>
            <td>
              <button class="btn secondary view-book" data-id="${book.id}">
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M2 12s3-7 10-7 10 7 10 7-3 7-10 7-10-7-10-7Z"></path><circle cx="12" cy="12" r="3"></circle></svg>
              </button>
              <button class="btn secondary edit-book" data-id="${book.id}">
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17 3a2.85 2.83 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5Z"></path><path d="m15 5 4 4"></path></svg>
              </button>
              <button class="btn secondary delete-book" data-id="${book.id}">
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 6h18"></path><path d="M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"></path><path d="M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"></path></svg>
              </button>
            </td>
          </tr>
        `;
      });
    }
    
    tableBody.innerHTML = tableHTML;
    
    // Create pagination
    createPagination('books', filteredBooks, currentPage, itemsPerPage, renderBooks);
    
    // Add event listeners to buttons
    document.querySelectorAll('.view-book').forEach(button => {
      button.addEventListener('click', (e) => {
        e.stopPropagation();
        const bookId = button.getAttribute('data-id');
        viewBook(bookId);
      });
    });
    
    document.querySelectorAll('.edit-book').forEach(button => {
      button.addEventListener('click', (e) => {
        e.stopPropagation();
        const bookId = button.getAttribute('data-id');
        editBook(bookId);
      });
    });
    
    document.querySelectorAll('.delete-book').forEach(button => {
      button.addEventListener('click', (e) => {
        e.stopPropagation();
        const bookId = button.getAttribute('data-id');
        deleteBook(bookId);
      });
    });
    
    // Add row click event for viewing
    document.querySelectorAll('#books-table tbody tr').forEach(row => {
      row.addEventListener('click', () => {
        const bookId = row.getAttribute('data-id');
        viewBook(bookId);
      });
    });
  }
  
  // Add new book
  function addBook() {
    document.getElementById('book-modal-title').textContent = 'Add New Book';
    document.getElementById('book-form').reset();
    document.getElementById('book-id').value = '';
    document.getElementById('book-available').checked = true;
    document.getElementById('book-available-text').textContent = 'Available';
    document.getElementById('book-save').textContent = 'Add Book';
    
    openModal('book-modal');
  }
  
  // Edit book
  function editBook(bookId) {
    const book = books.find(b => b.id === bookId);
    if (!book) return;
    
    document.getElementById('book-modal-title').textContent = 'Edit Book';
    fillFormData('book-form', book);
    document.getElementById('book-available-text').textContent = book.available ? 'Available' : 'Checked Out';
    document.getElementById('book-save').textContent = 'Save Changes';
    
    openModal('book-modal');
  }
  
  // View book details
  function viewBook(bookId) {
    const book = books.find(b => b.id === bookId);
    if (!book) return;
    
    document.getElementById('view-modal-title').textContent = 'Book Details';
    
    const content = `
      <div class="view-item">
        <div class="view-item-header">
          <div class="view-item-title">${book.title}</div>
          <div class="view-item-subtitle">by ${book.author}</div>
        </div>
        
        <div class="view-item-grid">
          <div class="view-item-section">
            <div>
              <div class="view-item-label">Genre</div>
              <div class="view-item-value">${book.genre}</div>
            </div>
            
            <div style="margin-top: 1rem;">
              <div class="view-item-label">Description</div>
              <div class="view-item-value">${book.description}</div>
            </div>
            
            <div style="margin-top: 1rem;" class="view-item-grid">
              <div>
                <div class="view-item-label">Condition</div>
                <div class="view-item-value">${getStatusBadge(book.condition, 'condition')}</div>
              </div>
              <div>
                <div class="view-item-label">Status</div>
                <div class="view-item-value">${getStatusBadge(book.available, 'availability')}</div>
              </div>
            </div>
            
            <div style="margin-top: 1rem;">
              <div class="view-item-label">Location</div>
              <div class="view-item-value">${book.location}</div>
            </div>
          </div>
          
          <div class="view-item-image">
            ${book.coverImage ? `
              <img src="${book.coverImage}" alt="${book.title}" />
            ` : `
              <div class="view-item-no-image">No cover image available</div>
            `}
          </div>
        </div>
      </div>
    `;
    
    document.getElementById('view-modal-content').innerHTML = content;
    openModal('view-modal');
  }
  
  // Delete book
  function deleteBook(bookId) {
    const book = books.find(b => b.id === bookId);
    if (!book) return;
    
    document.getElementById('delete-message').textContent = `Are you sure you want to delete "${book.title}" from the collection? This action cannot be undone.`;
    
    const confirmDeleteBtn = document.getElementById('confirm-delete');
    confirmDeleteBtn.onclick = () => {
      books = books.filter(b => b.id !== bookId);
      saveBooks();
      renderBooks(currentPage);
      closeModal('delete-modal');
      showToast('Book deleted', `"${book.title}" has been removed from the collection.`);
    };
    
    openModal('delete-modal');
  }
  
  // Save book (add or edit)
  function saveBook() {
    const formData = getFormData('book-form');
    const bookId = document.getElementById('book-id').value;
    
    if (bookId) {
      // Edit existing book
      const index = books.findIndex(b => b.id === bookId);
      if (index !== -1) {
        const updatedBook = {
          ...books[index],
          title: formData.title,
          author: formData.author,
          genre: formData.genre,
          description: formData.description,
          available: formData.available,
          condition: formData.condition,
          location: formData.location,
          coverImage: formData.coverImage || undefined
        };
        
        books[index] = updatedBook;
        showToast('Book updated', `"${formData.title}" has been updated.`);
      }
    } else {
      // Add new book
      const newBook = {
        id: generateId(),
        title: formData.title,
        author: formData.author,
        genre: formData.genre,
        description: formData.description,
        available: formData.available,
        condition: formData.condition,
        location: formData.location,
        coverImage: formData.coverImage || undefined
      };
      
      books.push(newBook);
      showToast('Book added', `"${formData.title}" has been added to the collection.`);
    }
    
    saveBooks();
    renderBooks();
    closeModal('book-modal');
  }
  
  // Initialize event listeners
  document.getElementById('add-book-btn').addEventListener('click', addBook);
  document.getElementById('book-save').addEventListener('click', saveBook);
  document.getElementById('books-search').addEventListener('input', () => renderBooks(1));
  
  // Load initial data
  loadBooks();
}

// Inventory Module
function initInventory() {
  let inventoryItems = [];
  let currentPage = 1;
  const itemsPerPage = 5;
  
  // Load data from localStorage
  function loadInventory() {
    const savedInventory = localStorage.getItem('cafe-inventory');
    if (savedInventory) {
      inventoryItems = JSON.parse(savedInventory);
    } else {
      // Sample data
      const today = new Date().toISOString().split('T')[0];
      const nextMonth = new Date(new Date().setMonth(new Date().getMonth() + 1)).toISOString().split('T')[0];
      
      inventoryItems = [
        {
          id: '1',
          name: 'Coffee Beans - Arabica',
          category: 'coffee',
          quantity: 15,
          unit: 'kg',
          minLevel: 5,
          supplier: 'Premium Coffee Co.',
          lastRestocked: today,
          expiryDate: nextMonth,
          notes: 'Dark roast'
        },
        {
          id: '2',
          name: 'Whole Milk',
          category: 'milk',
          quantity: 8,
          unit: 'L',
          minLevel: 4,
          supplier: 'Local Dairy',
          lastRestocked: today,
          expiryDate: new Date(new Date().setDate(new Date().getDate() + 7)).toISOString().split('T')[0],
          notes: ''
        },
        {
          id: '3',
          name: 'Vanilla Syrup',
          category: 'syrup',
          quantity: 3,
          unit: 'bottles',
          minLevel: 2,
          supplier: 'Flavor Inc.',
          lastRestocked: new Date(new Date().setDate(new Date().getDate() - 14)).toISOString().split('T')[0],
          notes: '1L bottles'
        },
        {
          id: '4',
          name: 'Paper Cups - 12oz',
          category: 'supplies',
          quantity: 250,
          unit: 'pcs',
          minLevel: 100,
          supplier: 'Cafe Supplies Co.',
          lastRestocked: new Date(new Date().setDate(new Date().getDate() - 30)).toISOString().split('T')[0],
          notes: ''
        }
      ];
      saveInventory();
    }
    renderInventory();
    
    // Set default date for last restocked
    const lastRestockedInput = document.getElementById('inventory-restocked');
    if (lastRestockedInput) {
      lastRestockedInput.value = new Date().toISOString().split('T')[0];
    }
  }
  
  // Save data to localStorage
  function saveInventory() {
    localStorage.setItem('cafe-inventory', JSON.stringify(inventoryItems));
  }
  
  // Get category label
  function getCategoryLabel(category) {
    const categoryLabels = {
      coffee: 'Coffee',
      tea: 'Tea',
      milk: 'Milk',
      syrup: 'Syrup',
      pastry: 'Pastry',
      supplies: 'Supplies',
      other: 'Other'
    };
    
    return categoryLabels[category] || category;
  }
  
  // Get stock level indicator
  function getStockLevelIndicator(item) {
    if (item.quantity <= 0) {
      return getStatusBadge('out-of-stock', 'stock');
    } else if (item.quantity <= item.minLevel) {
      return getStatusBadge('low-stock', 'stock');
    } else {
      return getStatusBadge('in-stock', 'stock');
    }
  }
  
  // Check if item is expired
  function isExpired(expiryDate) {
    if (!expiryDate) return false;
    
    const today = new Date();
    const expiry = new Date(expiryDate);
    return today > expiry;
  }
  
  // Check if item is near expiry
  function isNearExpiry(expiryDate) {
    if (!expiryDate) return false;
    
    const today = new Date();
    const expiry = new Date(expiryDate);
    const diffTime = expiry.getTime() - today.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    
    return diffDays > 0 && diffDays <= 7;
  }
  
  // Get expiry status
  function getExpiryStatus(expiryDate) {
    if (!expiryDate) return '';
    
    if (isExpired(expiryDate)) {
      return getStatusBadge('expired', 'expiry');
    } else if (isNearExpiry(expiryDate)) {
      return getStatusBadge('expiring-soon', 'expiry');
    }
    
    return formatDate(expiryDate);
  }
  
  // Render inventory table
  function renderInventory(page = 1) {
    currentPage = page;
    const tableBody = document.querySelector('#inventory-table tbody');
    const searchTerm = document.getElementById('inventory-search').value;
    const filteredInventory = filterData(inventoryItems, searchTerm);
    
    // Calculate pagination
    const startIndex = (currentPage - 1) * itemsPerPage;
    const paginatedInventory = filteredInventory.slice(startIndex, startIndex + itemsPerPage);
    
    // Generate table rows
    let tableHTML = '';
    
    if (paginatedInventory.length === 0) {
      tableHTML = `<tr><td colspan="7" class="text-center">No inventory items found.</td></tr>`;
    } else {
      paginatedInventory.forEach(item => {
        tableHTML += `
          <tr data-id="${item.id}">
            <td>${item.name}</td>
            <td>${getCategoryLabel(item.category)}</td>
            <td>${item.quantity} ${item.unit}</td>
            <td>${getStockLevelIndicator(item)}</td>
            <td>${item.supplier}</td>
            <td>${getExpiryStatus(item.expiryDate)}</td>
            <td>
              <button class="btn secondary edit-inventory" data-id="${item.id}">
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17 3a2.85 2.83 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5Z"></path><path d="m15 5 4 4"></path></svg>
              </button>
              <button class="btn secondary delete-inventory" data-id="${item.id}">
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 6h18"></path><path d="M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"></path><path d="M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"></path></svg>
              </button>
            </td>
          </tr>
        `;
      });
    }
    
    tableBody.innerHTML = tableHTML;
    
    // Create pagination
    createPagination('inventory', filteredInventory, currentPage, itemsPerPage, renderInventory);
    
    // Add event listeners to buttons
    document.querySelectorAll('.edit-inventory').forEach(button => {
      button.addEventListener('click', (e) => {
        e.stopPropagation();
        const inventoryId = button.getAttribute('data-id');
        editInventoryItem(inventoryId);
      });
    });
    
    document.querySelectorAll('.delete-inventory').forEach(button => {
      button.addEventListener('click', (e) => {
        e.stopPropagation();
        const inventoryId = button.getAttribute('data-id');
        deleteInventoryItem(inventoryId);
      });
    });
    
    // Add row click event for editing
    document.querySelectorAll('#inventory-table tbody tr').forEach(row => {
      row.addEventListener('click', () => {
        const inventoryId = row.getAttribute('data-id');
        editInventoryItem(inventoryId);
      });
    });
  }
  
  // Add new inventory item
  function addInventoryItem() {
    document.getElementById('inventory-modal-title').textContent = 'Add New Inventory Item';
    document.getElementById('inventory-form').reset();
    document.getElementById('inventory-id').value = '';
    document.getElementById('inventory-restocked').value = new Date().toISOString().split('T')[0];
    document.getElementById('inventory-save').textContent = 'Add Item';
    
    openModal('inventory-modal');
  }
  
  // Edit inventory item
  function editInventoryItem(inventoryId) {
    const inventoryItem = inventoryItems.find(item => item.id === inventoryId);
    if (!inventoryItem) return;
    
    document.getElementById('inventory-modal-title').textContent = 'Edit Inventory Item';
    fillFormData('inventory-form', inventoryItem);
    document.getElementById('inventory-save').textContent = 'Save Changes';
    
    openModal('inventory-modal');
  }
  
  // Delete inventory item
  function deleteInventoryItem(inventoryId) {
    const inventoryItem = inventoryItems.find(item => item.id === inventoryId);
    if (!inventoryItem) return;
    
    document.getElementById('delete-message').textContent = `Are you sure you want to delete ${inventoryItem.name} from inventory? This action cannot be undone.`;
    
    const confirmDeleteBtn = document.getElementById('confirm-delete');
    confirmDeleteBtn.onclick = () => {
      inventoryItems = inventoryItems.filter(item => item.id !== inventoryId);
      saveInventory();
      renderInventory(currentPage);
      closeModal('delete-modal');
      showToast('Inventory item deleted', `${inventoryItem.name} has been removed from inventory.`);
    };
    
    openModal('delete-modal');
  }
  
  // Save inventory item (add or edit)
  function saveInventoryItem() {
    const formData = getFormData('inventory-form');
    const inventoryId = document.getElementById('inventory-id').value;
    
    if (inventoryId) {
      // Edit existing inventory item
      const index = inventoryItems.findIndex(item => item.id === inventoryId);
      if (index !== -1) {
        const updatedInventoryItem = {
          ...inventoryItems[index],
          name: formData.name,
          category: formData.category,
          quantity: parseInt(formData.quantity) || 0,
          unit: formData.unit,
          minLevel: parseInt(formData.minLevel) || 0,
          supplier: formData.supplier,
          lastRestocked: formData.lastRestocked,
          expiryDate: formData.expiryDate || undefined,
          notes: formData.notes
        };
        
        inventoryItems[index] = updatedInventoryItem;
        showToast('Inventory item updated', `${formData.name} has been updated.`);
      }
    } else {
      // Add new inventory item
      const newInventoryItem = {
        id: generateId(),
        name: formData.name,
        category: formData.category,
        quantity: parseInt(formData.quantity) || 0,
        unit: formData.unit,
        minLevel: parseInt(formData.minLevel) || 0,
        supplier: formData.supplier,
        lastRestocked: formData.lastRestocked,
        expiryDate: formData.expiryDate || undefined,
        notes: formData.notes
      };
      
      inventoryItems.push(newInventoryItem);
      showToast('Inventory item added', `${formData.name} has been added to inventory.`);
    }
    
    saveInventory();
    renderInventory();
    closeModal('inventory-modal');
  }
  
  // Initialize event listeners
  document.getElementById('add-inventory-btn').addEventListener('click', addInventoryItem);
  document.getElementById('inventory-save').addEventListener('click', saveInventoryItem);
  document.getElementById('inventory-search').addEventListener('input', () => renderInventory(1));
  
  // Load initial data
  loadInventory();
}