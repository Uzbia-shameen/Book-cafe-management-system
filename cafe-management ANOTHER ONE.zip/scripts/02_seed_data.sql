-- Seed data for cafe management system
USE cafe_management;

-- Insert sample customers
INSERT INTO customers (name, email, phone, address) VALUES
('John Doe', 'john.doe@email.com', '+1234567890', '123 Main St, City, State'),
('Jane Smith', 'jane.smith@email.com', '+1234567891', '456 Oak Ave, City, State'),
('Mike Johnson', 'mike.johnson@email.com', '+1234567892', '789 Pine Rd, City, State'),
('Sarah Wilson', 'sarah.wilson@email.com', '+1234567893', '321 Elm St, City, State'),
('David Brown', 'david.brown@email.com', '+1234567894', '654 Maple Dr, City, State');

-- Insert sample cafe items
INSERT INTO cafe_items (name, description, price, category, is_available) VALUES
('Espresso', 'Rich and bold espresso shot', 3.50, 'beverage', TRUE),
('Cappuccino', 'Espresso with steamed milk and foam', 4.25, 'beverage', TRUE),
('Latte', 'Espresso with steamed milk', 4.75, 'beverage', TRUE),
('Americano', 'Espresso with hot water', 3.75, 'beverage', TRUE),
('Mocha', 'Espresso with chocolate and steamed milk', 5.25, 'beverage', TRUE),
('Croissant', 'Buttery, flaky pastry', 3.00, 'food', TRUE),
('Blueberry Muffin', 'Fresh baked muffin with blueberries', 3.50, 'food', TRUE),
('Avocado Toast', 'Toasted bread with fresh avocado', 8.50, 'food', TRUE),
('Caesar Salad', 'Fresh romaine with caesar dressing', 9.75, 'food', TRUE),
('Grilled Sandwich', 'Grilled sandwich with cheese and ham', 7.25, 'food', TRUE);

-- Insert sample books
INSERT INTO books (title, author, isbn, genre, price, is_available) VALUES
('The Great Gatsby', 'F. Scott Fitzgerald', '9780743273565', 'Classic Literature', 12.99, TRUE),
('To Kill a Mockingbird', 'Harper Lee', '9780061120084', 'Classic Literature', 13.99, TRUE),
('1984', 'George Orwell', '9780451524935', 'Dystopian Fiction', 13.99, TRUE),
('Pride and Prejudice', 'Jane Austen', '9780141439518', 'Romance', 11.99, TRUE),
('The Catcher in the Rye', 'J.D. Salinger', '9780316769174', 'Coming of Age', 12.99, TRUE),
('Harry Potter and the Sorcerer\'s Stone', 'J.K. Rowling', '9780439708180', 'Fantasy', 14.99, TRUE),
('The Hobbit', 'J.R.R. Tolkien', '9780547928227', 'Fantasy', 13.99, TRUE),
('Dune', 'Frank Herbert', '9780441172719', 'Science Fiction', 15.99, TRUE);

-- Insert sample inventory items
INSERT INTO inventory (item_name, category, current_stock, minimum_stock, unit, cost_per_unit, supplier) VALUES
('Coffee Beans - Arabica', 'beverage', 50, 10, 'kg', 25.00, 'Premium Coffee Suppliers'),
('Milk', 'beverage', 20, 5, 'liters', 3.50, 'Local Dairy Farm'),
('Sugar', 'beverage', 15, 3, 'kg', 2.00, 'Sweet Supplies Co'),
('Flour', 'food', 25, 5, 'kg', 1.50, 'Baking Essentials'),
('Eggs', 'food', 100, 20, 'pieces', 0.25, 'Farm Fresh Eggs'),
('Butter', 'food', 10, 2, 'kg', 8.00, 'Dairy Products Inc'),
('Bread', 'food', 30, 10, 'loaves', 2.50, 'Local Bakery'),
('Avocados', 'food', 25, 5, 'pieces', 1.50, 'Fresh Produce Market'),
('Lettuce', 'food', 15, 3, 'heads', 2.00, 'Green Vegetables Co'),
('Cheese', 'food', 8, 2, 'kg', 12.00, 'Artisan Cheese Shop');

-- Insert sample reservations
INSERT INTO reservations (customer_id, table_number, reservation_date, reservation_time, party_size, status, special_requests) VALUES
(1, 5, '2024-12-15', '18:00:00', 2, 'confirmed', 'Window seat preferred'),
(2, 3, '2024-12-16', '12:30:00', 4, 'confirmed', 'Birthday celebration'),
(3, 7, '2024-12-17', '19:30:00', 2, 'pending', 'Quiet area please'),
(4, 2, '2024-12-18', '11:00:00', 3, 'confirmed', 'High chair needed'),
(5, 8, '2024-12-19', '20:00:00', 6, 'pending', 'Business meeting');

-- Insert sample orders
INSERT INTO orders (customer_id, reservation_id, total_amount, status, order_type, notes) VALUES
(1, 1, 15.50, 'completed', 'dine_in', 'Extra hot coffee'),
(2, 2, 32.75, 'served', 'dine_in', 'Birthday special'),
(3, NULL, 8.25, 'ready', 'takeaway', 'No sugar in coffee'),
(4, 4, 21.00, 'preparing', 'dine_in', 'Kid-friendly meal'),
(5, NULL, 12.50, 'pending', 'delivery', 'Office address');

-- Insert sample order items
INSERT INTO order_items (order_id, cafe_item_id, book_id, quantity, unit_price, total_price, item_type) VALUES
(1, 2, NULL, 2, 4.25, 8.50, 'beverage'),
(1, 6, NULL, 1, 3.00, 3.00, 'food'),
(1, 1, NULL, 1, 12.99, 12.99, 'book'),
(2, 3, NULL, 3, 4.75, 14.25, 'beverage'),
(2, 8, NULL, 2, 8.50, 17.00, 'food'),
(2, 2, NULL, 1, 13.99, 13.99, 'book'),
(3, 1, NULL, 1, 3.50, 3.50, 'beverage'),
(3, 7, NULL, 1, 3.50, 3.50, 'food'),
(4, 4, NULL, 2, 3.75, 7.50, 'beverage'),
(4, 9, NULL, 1, 9.75, 9.75, 'food'),
(5, 5, NULL, 1, 5.25, 5.25, 'beverage'),
(5, 10, NULL, 1, 7.25, 7.25, 'food');

-- Insert sample payments
INSERT INTO payments (order_id, amount, payment_method, payment_status, transaction_id) VALUES
(1, 15.50, 'card', 'completed', 'TXN001234567'),
(2, 32.75, 'cash', 'completed', NULL),
(3, 8.25, 'digital_wallet', 'completed', 'DW789012345'),
(4, 21.00, 'card', 'pending', 'TXN001234568'),
(5, 12.50, 'digital_wallet', 'pending', 'DW789012346');
