<?php
require_once '../config/database.php';

$database = new Database();
$db = $database->getConnection();

$method = $_SERVER['REQUEST_METHOD'];

switch($method) {
    case 'GET':
        if (isset($_GET['id'])) {
            getPayment($db, $_GET['id']);
        } elseif (isset($_GET['order_id'])) {
            getPaymentsByOrder($db, $_GET['order_id']);
        } else {
            getAllPayments($db);
        }
        break;
    
    case 'POST':
        createPayment($db);
        break;
    
    case 'PUT':
        updatePayment($db);
        break;
    
    case 'DELETE':
        deletePayment($db);
        break;
    
    default:
        http_response_code(405);
        echo json_encode(array("message" => "Method not allowed"));
        break;
}

function getAllPayments($db) {
    $query = "SELECT p.*, o.total_amount as order_total, c.name as customer_name 
              FROM payments p 
              LEFT JOIN orders o ON p.order_id = o.id 
              LEFT JOIN customers c ON o.customer_id = c.id 
              ORDER BY p.payment_date DESC";
    $stmt = $db->prepare($query);
    $stmt->execute();
    
    $payments = $stmt->fetchAll();
    echo json_encode($payments);
}

function getPayment($db, $id) {
    $query = "SELECT p.*, o.total_amount as order_total, c.name as customer_name 
              FROM payments p 
              LEFT JOIN orders o ON p.order_id = o.id 
              LEFT JOIN customers c ON o.customer_id = c.id 
              WHERE p.id = :id";
    $stmt = $db->prepare($query);
    $stmt->bindParam(':id', $id);
    $stmt->execute();
    
    $payment = $stmt->fetch();
    if ($payment) {
        echo json_encode($payment);
    } else {
        http_response_code(404);
        echo json_encode(array("message" => "Payment not found"));
    }
}

function getPaymentsByOrder($db, $order_id) {
    $query = "SELECT * FROM payments WHERE order_id = :order_id ORDER BY payment_date DESC";
    $stmt = $db->prepare($query);
    $stmt->bindParam(':order_id', $order_id);
    $stmt->execute();
    
    $payments = $stmt->fetchAll();
    echo json_encode($payments);
}

function createPayment($db) {
    $data = json_decode(file_get_contents("php://input"));
    
    if (!empty($data->order_id) && !empty($data->amount) && !empty($data->payment_method)) {
        $query = "INSERT INTO payments (order_id, amount, payment_method, payment_status, transaction_id) 
                  VALUES (:order_id, :amount, :payment_method, :payment_status, :transaction_id)";
        $stmt = $db->prepare($query);
        
        $stmt->bindParam(':order_id', $data->order_id);
        $stmt->bindParam(':amount', $data->amount);
        $stmt->bindParam(':payment_method', $data->payment_method);
        $stmt->bindParam(':payment_status', $data->payment_status);
        $stmt->bindParam(':transaction_id', $data->transaction_id);
        
        if ($stmt->execute()) {
            http_response_code(201);
            echo json_encode(array("message" => "Payment created successfully", "id" => $db->lastInsertId()));
        } else {
            http_response_code(503);
            echo json_encode(array("message" => "Unable to create payment"));
        }
    } else {
        http_response_code(400);
        echo json_encode(array("message" => "Unable to create payment. Data is incomplete"));
    }
}

function updatePayment($db) {
    $data = json_decode(file_get_contents("php://input"));
    
    if (!empty($data->id)) {
        $query = "UPDATE payments SET payment_status = :payment_status, transaction_id = :transaction_id WHERE id = :id";
        $stmt = $db->prepare($query);
        
        $stmt->bindParam(':id', $data->id);
        $stmt->bindParam(':payment_status', $data->payment_status);
        $stmt->bindParam(':transaction_id', $data->transaction_id);
        
        if ($stmt->execute()) {
            echo json_encode(array("message" => "Payment updated successfully"));
        } else {
            http_response_code(503);
            echo json_encode(array("message" => "Unable to update payment"));
        }
    } else {
        http_response_code(400);
        echo json_encode(array("message" => "Unable to update payment. Data is incomplete"));
    }
}

function deletePayment($db) {
    $data = json_decode(file_get_contents("php://input"));
    
    if (!empty($data->id)) {
        $query = "DELETE FROM payments WHERE id = :id";
        $stmt = $db->prepare($query);
        $stmt->bindParam(':id', $data->id);
        
        if ($stmt->execute()) {
            echo json_encode(array("message" => "Payment deleted successfully"));
        } else {
            http_response_code(503);
            echo json_encode(array("message" => "Unable to delete payment"));
        }
    } else {
        http_response_code(400);
        echo json_encode(array("message" => "Unable to delete payment. Data is incomplete"));
    }
}
?>
