<?php
require_once '../config/database.php';

$database = new Database();
$db = $database->getConnection();

$method = $_SERVER['REQUEST_METHOD'];

switch($method) {
    case 'GET':
        if (isset($_GET['id'])) {
            getOrder($db, $_GET['id']);
        } else {
            getAllOrders($db);
        }
        break;
    
    case 'POST':
        createOrder($db);
        break;
    
    case 'PUT':
        updateOrder($db);
        break;
    
    case 'DELETE':
        deleteOrder($db);
        break;
    
    default:
        http_response_code(405);
        echo json_encode(array("message" => "Method not allowed"));
        break;
}

function getAllOrders($db) {
    $query = "SELECT o.*, c.name as customer_name, c.email as customer_email 
              FROM orders o 
              LEFT JOIN customers c ON o.customer_id = c.id 
              ORDER BY o.created_at DESC";
    $stmt = $db->prepare($query);
    $stmt->execute();
    
    $orders = $stmt->fetchAll();
    
    // Get order items for each order
    foreach ($orders as &$order) {
        $itemQuery = "SELECT oi.*, ci.name as item_name, b.title as book_title 
                      FROM order_items oi 
                      LEFT JOIN cafe_items ci ON oi.cafe_item_id = ci.id 
                      LEFT JOIN books b ON oi.book_id = b.id 
                      WHERE oi.order_id = :order_id";
        $itemStmt = $db->prepare($itemQuery);
        $itemStmt->bindParam(':order_id', $order['id']);
        $itemStmt->execute();
        $order['items'] = $itemStmt->fetchAll();
    }
    
    echo json_encode($orders);
}

function getOrder($db, $id) {
    $query = "SELECT o.*, c.name as customer_name, c.email as customer_email 
              FROM orders o 
              LEFT JOIN customers c ON o.customer_id = c.id 
              WHERE o.id = :id";
    $stmt = $db->prepare($query);
    $stmt->bindParam(':id', $id);
    $stmt->execute();
    
    $order = $stmt->fetch();
    if ($order) {
        // Get order items
        $itemQuery = "SELECT oi.*, ci.name as item_name, b.title as book_title 
                      FROM order_items oi 
                      LEFT JOIN cafe_items ci ON oi.cafe_item_id = ci.id 
                      LEFT JOIN books b ON oi.book_id = b.id 
                      WHERE oi.order_id = :order_id";
        $itemStmt = $db->prepare($itemQuery);
        $itemStmt->bindParam(':order_id', $order['id']);
        $itemStmt->execute();
        $order['items'] = $itemStmt->fetchAll();
        
        echo json_encode($order);
    } else {
        http_response_code(404);
        echo json_encode(array("message" => "Order not found"));
    }
}

function createOrder($db) {
    $data = json_decode(file_get_contents("php://input"));
    
    if (!empty($data->items) && is_array($data->items)) {
        try {
            $db->beginTransaction();
            
            // Create order
            $query = "INSERT INTO orders (customer_id, reservation_id, total_amount, status, order_type, notes) 
                      VALUES (:customer_id, :reservation_id, :total_amount, :status, :order_type, :notes)";
            $stmt = $db->prepare($query);
            
            $stmt->bindParam(':customer_id', $data->customer_id);
            $stmt->bindParam(':reservation_id', $data->reservation_id);
            $stmt->bindParam(':total_amount', $data->total_amount);
            $stmt->bindParam(':status', $data->status);
            $stmt->bindParam(':order_type', $data->order_type);
            $stmt->bindParam(':notes', $data->notes);
            
            $stmt->execute();
            $order_id = $db->lastInsertId();
            
            // Create order items
            $itemQuery = "INSERT INTO order_items (order_id, cafe_item_id, book_id, quantity, unit_price, total_price, item_type) 
                          VALUES (:order_id, :cafe_item_id, :book_id, :quantity, :unit_price, :total_price, :item_type)";
            $itemStmt = $db->prepare($itemQuery);
            
            foreach ($data->items as $item) {
                $itemStmt->bindParam(':order_id', $order_id);
                $itemStmt->bindParam(':cafe_item_id', $item->cafe_item_id);
                $itemStmt->bindParam(':book_id', $item->book_id);
                $itemStmt->bindParam(':quantity', $item->quantity);
                $itemStmt->bindParam(':unit_price', $item->unit_price);
                $itemStmt->bindParam(':total_price', $item->total_price);
                $itemStmt->bindParam(':item_type', $item->item_type);
                $itemStmt->execute();
            }
            
            $db->commit();
            
            http_response_code(201);
            echo json_encode(array("message" => "Order created successfully", "id" => $order_id));
        } catch (Exception $e) {
            $db->rollback();
            http_response_code(503);
            echo json_encode(array("message" => "Unable to create order: " . $e->getMessage()));
        }
    } else {
        http_response_code(400);
        echo json_encode(array("message" => "Unable to create order. Data is incomplete"));
    }
}

function updateOrder($db) {
    $data = json_decode(file_get_contents("php://input"));
    
    if (!empty($data->id)) {
        $query = "UPDATE orders SET status = :status, notes = :notes WHERE id = :id";
        $stmt = $db->prepare($query);
        
        $stmt->bindParam(':id', $data->id);
        $stmt->bindParam(':status', $data->status);
        $stmt->bindParam(':notes', $data->notes);
        
        if ($stmt->execute()) {
            echo json_encode(array("message" => "Order updated successfully"));
        } else {
            http_response_code(503);
            echo json_encode(array("message" => "Unable to update order"));
        }
    } else {
        http_response_code(400);
        echo json_encode(array("message" => "Unable to update order. Data is incomplete"));
    }
}

function deleteOrder($db) {
    $data = json_decode(file_get_contents("php://input"));
    
    if (!empty($data->id)) {
        $query = "DELETE FROM orders WHERE id = :id";
        $stmt = $db->prepare($query);
        $stmt->bindParam(':id', $data->id);
        
        if ($stmt->execute()) {
            echo json_encode(array("message" => "Order deleted successfully"));
        } else {
            http_response_code(503);
            echo json_encode(array("message" => "Unable to delete order"));
        }
    } else {
        http_response_code(400);
        echo json_encode(array("message" => "Unable to delete order. Data is incomplete"));
    }
}
?>
