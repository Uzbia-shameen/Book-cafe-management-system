<?php
require_once '../config/database.php';

$database = new Database();
$db = $database->getConnection();

$method = $_SERVER['REQUEST_METHOD'];

switch($method) {
    case 'GET':
        if (isset($_GET['id'])) {
            getInventoryItem($db, $_GET['id']);
        } elseif (isset($_GET['low_stock'])) {
            getLowStockItems($db);
        } else {
            getAllInventoryItems($db);
        }
        break;
    
    case 'POST':
        createInventoryItem($db);
        break;
    
    case 'PUT':
        updateInventoryItem($db);
        break;
    
    case 'DELETE':
        deleteInventoryItem($db);
        break;
    
    default:
        http_response_code(405);
        echo json_encode(array("message" => "Method not allowed"));
        break;
}

function getAllInventoryItems($db) {
    $query = "SELECT *, 
              CASE WHEN current_stock <= minimum_stock THEN 1 ELSE 0 END as is_low_stock 
              FROM inventory ORDER BY category, item_name";
    $stmt = $db->prepare($query);
    $stmt->execute();
    
    $items = $stmt->fetchAll();
    echo json_encode($items);
}

function getInventoryItem($db, $id) {
    $query = "SELECT *, 
              CASE WHEN current_stock <= minimum_stock THEN 1 ELSE 0 END as is_low_stock 
              FROM inventory WHERE id = :id";
    $stmt = $db->prepare($query);
    $stmt->bindParam(':id', $id);
    $stmt->execute();
    
    $item = $stmt->fetch();
    if ($item) {
        echo json_encode($item);
    } else {
        http_response_code(404);
        echo json_encode(array("message" => "Inventory item not found"));
    }
}

function getLowStockItems($db) {
    $query = "SELECT *, 
              CASE WHEN current_stock <= minimum_stock THEN 1 ELSE 0 END as is_low_stock 
              FROM inventory WHERE current_stock <= minimum_stock 
              ORDER BY category, item_name";
    $stmt = $db->prepare($query);
    $stmt->execute();
    
    $items = $stmt->fetchAll();
    echo json_encode($items);
}

function createInventoryItem($db) {
    $data = json_decode(file_get_contents("php://input"));
    
    if (!empty($data->item_name) && !empty($data->category) && isset($data->current_stock) && isset($data->minimum_stock)) {
        $query = "INSERT INTO inventory (item_name, category, current_stock, minimum_stock, unit, cost_per_unit, supplier, last_restocked) 
                  VALUES (:item_name, :category, :current_stock, :minimum_stock, :unit, :cost_per_unit, :supplier, :last_restocked)";
        $stmt = $db->prepare($query);
        
        $stmt->bindParam(':item_name', $data->item_name);
        $stmt->bindParam(':category', $data->category);
        $stmt->bindParam(':current_stock', $data->current_stock);
        $stmt->bindParam(':minimum_stock', $data->minimum_stock);
        $stmt->bindParam(':unit', $data->unit);
        $stmt->bindParam(':cost_per_unit', $data->cost_per_unit);
        $stmt->bindParam(':supplier', $data->supplier);
        $stmt->bindParam(':last_restocked', $data->last_restocked);
        
        if ($stmt->execute()) {
            http_response_code(201);
            echo json_encode(array("message" => "Inventory item created successfully", "id" => $db->lastInsertId()));
        } else {
            http_response_code(503);
            echo json_encode(array("message" => "Unable to create inventory item"));
        }
    } else {
        http_response_code(400);
        echo json_encode(array("message" => "Unable to create inventory item. Data is incomplete"));
    }
}

function updateInventoryItem($db) {
    $data = json_decode(file_get_contents("php://input"));
    
    if (!empty($data->id)) {
        $query = "UPDATE inventory SET item_name = :item_name, category = :category, 
                  current_stock = :current_stock, minimum_stock = :minimum_stock, 
                  unit = :unit, cost_per_unit = :cost_per_unit, supplier = :supplier, 
                  last_restocked = :last_restocked WHERE id = :id";
        $stmt = $db->prepare($query);
        
        $stmt->bindParam(':id', $data->id);
        $stmt->bindParam(':item_name', $data->item_name);
        $stmt->bindParam(':category', $data->category);
        $stmt->bindParam(':current_stock', $data->current_stock);
        $stmt->bindParam(':minimum_stock', $data->minimum_stock);
        $stmt->bindParam(':unit', $data->unit);
        $stmt->bindParam(':cost_per_unit', $data->cost_per_unit);
        $stmt->bindParam(':supplier', $data->supplier);
        $stmt->bindParam(':last_restocked', $data->last_restocked);
        
        if ($stmt->execute()) {
            echo json_encode(array("message" => "Inventory item updated successfully"));
        } else {
            http_response_code(503);
            echo json_encode(array("message" => "Unable to update inventory item"));
        }
    } else {
        http_response_code(400);
        echo json_encode(array("message" => "Unable to update inventory item. Data is incomplete"));
    }
}

function deleteInventoryItem($db) {
    $data = json_decode(file_get_contents("php://input"));
    
    if (!empty($data->id)) {
        $query = "DELETE FROM inventory WHERE id = :id";
        $stmt = $db->prepare($query);
        $stmt->bindParam(':id', $data->id);
        
        if ($stmt->execute()) {
            echo json_encode(array("message" => "Inventory item deleted successfully"));
        } else {
            http_response_code(503);
            echo json_encode(array("message" => "Unable to delete inventory item"));
        }
    } else {
        http_response_code(400);
        echo json_encode(array("message" => "Unable to delete inventory item. Data is incomplete"));
    }
}
?>
