<?php
require_once '../config/database.php';

$database = new Database();
$db = $database->getConnection();

$method = $_SERVER['REQUEST_METHOD'];

switch($method) {
    case 'GET':
        if (isset($_GET['id'])) {
            getReservation($db, $_GET['id']);
        } elseif (isset($_GET['date'])) {
            getReservationsByDate($db, $_GET['date']);
        } else {
            getAllReservations($db);
        }
        break;
    
    case 'POST':
        createReservation($db);
        break;
    
    case 'PUT':
        updateReservation($db);
        break;
    
    case 'DELETE':
        deleteReservation($db);
        break;
    
    default:
        http_response_code(405);
        echo json_encode(array("message" => "Method not allowed"));
        break;
}

function getAllReservations($db) {
    $query = "SELECT r.*, c.name as customer_name, c.email as customer_email, c.phone as customer_phone 
              FROM reservations r 
              LEFT JOIN customers c ON r.customer_id = c.id 
              ORDER BY r.reservation_date DESC, r.reservation_time DESC";
    $stmt = $db->prepare($query);
    $stmt->execute();
    
    $reservations = $stmt->fetchAll();
    echo json_encode($reservations);
}

function getReservation($db, $id) {
    $query = "SELECT r.*, c.name as customer_name, c.email as customer_email, c.phone as customer_phone 
              FROM reservations r 
              LEFT JOIN customers c ON r.customer_id = c.id 
              WHERE r.id = :id";
    $stmt = $db->prepare($query);
    $stmt->bindParam(':id', $id);
    $stmt->execute();
    
    $reservation = $stmt->fetch();
    if ($reservation) {
        echo json_encode($reservation);
    } else {
        http_response_code(404);
        echo json_encode(array("message" => "Reservation not found"));
    }
}

function getReservationsByDate($db, $date) {
    $query = "SELECT r.*, c.name as customer_name, c.email as customer_email, c.phone as customer_phone 
              FROM reservations r 
              LEFT JOIN customers c ON r.customer_id = c.id 
              WHERE r.reservation_date = :date 
              ORDER BY r.reservation_time";
    $stmt = $db->prepare($query);
    $stmt->bindParam(':date', $date);
    $stmt->execute();
    
    $reservations = $stmt->fetchAll();
    echo json_encode($reservations);
}

function createReservation($db) {
    $data = json_decode(file_get_contents("php://input"));
    
    if (!empty($data->table_number) && !empty($data->reservation_date) && !empty($data->reservation_time) && !empty($data->party_size)) {
        $query = "INSERT INTO reservations (customer_id, table_number, reservation_date, reservation_time, party_size, status, special_requests) 
                  VALUES (:customer_id, :table_number, :reservation_date, :reservation_time, :party_size, :status, :special_requests)";
        $stmt = $db->prepare($query);
        
        $stmt->bindParam(':customer_id', $data->customer_id);
        $stmt->bindParam(':table_number', $data->table_number);
        $stmt->bindParam(':reservation_date', $data->reservation_date);
        $stmt->bindParam(':reservation_time', $data->reservation_time);
        $stmt->bindParam(':party_size', $data->party_size);
        $stmt->bindParam(':status', $data->status);
        $stmt->bindParam(':special_requests', $data->special_requests);
        
        if ($stmt->execute()) {
            http_response_code(201);
            echo json_encode(array("message" => "Reservation created successfully", "id" => $db->lastInsertId()));
        } else {
            http_response_code(503);
            echo json_encode(array("message" => "Unable to create reservation"));
        }
    } else {
        http_response_code(400);
        echo json_encode(array("message" => "Unable to create reservation. Data is incomplete"));
    }
}

function updateReservation($db) {
    $data = json_decode(file_get_contents("php://input"));
    
    if (!empty($data->id)) {
        $query = "UPDATE reservations SET table_number = :table_number, reservation_date = :reservation_date, 
                  reservation_time = :reservation_time, party_size = :party_size, status = :status, 
                  special_requests = :special_requests WHERE id = :id";
        $stmt = $db->prepare($query);
        
        $stmt->bindParam(':id', $data->id);
        $stmt->bindParam(':table_number', $data->table_number);
        $stmt->bindParam(':reservation_date', $data->reservation_date);
        $stmt->bindParam(':reservation_time', $data->reservation_time);
        $stmt->bindParam(':party_size', $data->party_size);
        $stmt->bindParam(':status', $data->status);
        $stmt->bindParam(':special_requests', $data->special_requests);
        
        if ($stmt->execute()) {
            echo json_encode(array("message" => "Reservation updated successfully"));
        } else {
            http_response_code(503);
            echo json_encode(array("message" => "Unable to update reservation"));
        }
    } else {
        http_response_code(400);
        echo json_encode(array("message" => "Unable to update reservation. Data is incomplete"));
    }
}

function deleteReservation($db) {
    $data = json_decode(file_get_contents("php://input"));
    
    if (!empty($data->id)) {
        $query = "DELETE FROM reservations WHERE id = :id";
        $stmt = $db->prepare($query);
        $stmt->bindParam(':id', $data->id);
        
        if ($stmt->execute()) {
            echo json_encode(array("message" => "Reservation deleted successfully"));
        } else {
            http_response_code(503);
            echo json_encode(array("message" => "Unable to delete reservation"));
        }
    } else {
        http_response_code(400);
        echo json_encode(array("message" => "Unable to delete reservation. Data is incomplete"));
    }
}
?>
