<?php
require_once '../config/database.php';

$database = new Database();
$db = $database->getConnection();

$method = $_SERVER['REQUEST_METHOD'];

switch($method) {
    case 'GET':
        if (isset($_GET['id'])) {
            getCustomer($db, $_GET['id']);
        } else {
            getAllCustomers($db);
        }
        break;
    
    case 'POST':
        createCustomer($db);
        break;
    
    case 'PUT':
        updateCustomer($db);
        break;
    
    case 'DELETE':
        deleteCustomer($db);
        break;
    
    default:
        http_response_code(405);
        echo json_encode(array("message" => "Method not allowed"));
        break;
}

function getAllCustomers($db) {
    $query = "SELECT * FROM customers ORDER BY created_at DESC";
    $stmt = $db->prepare($query);
    $stmt->execute();
    
    $customers = $stmt->fetchAll();
    echo json_encode($customers);
}

function getCustomer($db, $id) {
    $query = "SELECT * FROM customers WHERE id = :id";
    $stmt = $db->prepare($query);
    $stmt->bindParam(':id', $id);
    $stmt->execute();
    
    $customer = $stmt->fetch();
    if ($customer) {
        echo json_encode($customer);
    } else {
        http_response_code(404);
        echo json_encode(array("message" => "Customer not found"));
    }
}

function createCustomer($db) {
    $data = json_decode(file_get_contents("php://input"));
    
    if (!empty($data->name) && !empty($data->email)) {
        $query = "INSERT INTO customers (name, email, phone, address) VALUES (:name, :email, :phone, :address)";
        $stmt = $db->prepare($query);
        
        $stmt->bindParam(':name', $data->name);
        $stmt->bindParam(':email', $data->email);
        $stmt->bindParam(':phone', $data->phone);
        $stmt->bindParam(':address', $data->address);
        
        if ($stmt->execute()) {
            http_response_code(201);
            echo json_encode(array("message" => "Customer created successfully", "id" => $db->lastInsertId()));
        } else {
            http_response_code(503);
            echo json_encode(array("message" => "Unable to create customer"));
        }
    } else {
        http_response_code(400);
        echo json_encode(array("message" => "Unable to create customer. Data is incomplete"));
    }
}

function updateCustomer($db) {
    $data = json_decode(file_get_contents("php://input"));
    
    if (!empty($data->id)) {
        $query = "UPDATE customers SET name = :name, email = :email, phone = :phone, address = :address WHERE id = :id";
        $stmt = $db->prepare($query);
        
        $stmt->bindParam(':id', $data->id);
        $stmt->bindParam(':name', $data->name);
        $stmt->bindParam(':email', $data->email);
        $stmt->bindParam(':phone', $data->phone);
        $stmt->bindParam(':address', $data->address);
        
        if ($stmt->execute()) {
            echo json_encode(array("message" => "Customer updated successfully"));
        } else {
            http_response_code(503);
            echo json_encode(array("message" => "Unable to update customer"));
        }
    } else {
        http_response_code(400);
        echo json_encode(array("message" => "Unable to update customer. Data is incomplete"));
    }
}

function deleteCustomer($db) {
    $data = json_decode(file_get_contents("php://input"));
    
    if (!empty($data->id)) {
        $query = "DELETE FROM customers WHERE id = :id";
        $stmt = $db->prepare($query);
        $stmt->bindParam(':id', $data->id);
        
        if ($stmt->execute()) {
            echo json_encode(array("message" => "Customer deleted successfully"));
        } else {
            http_response_code(503);
            echo json_encode(array("message" => "Unable to delete customer"));
        }
    } else {
        http_response_code(400);
        echo json_encode(array("message" => "Unable to delete customer. Data is incomplete"));
    }
}
?>
