<?php
require_once '../config/database.php';

$database = new Database();
$db = $database->getConnection();

$method = $_SERVER['REQUEST_METHOD'];

switch($method) {
    case 'GET':
        if (isset($_GET['id'])) {
            getMenuItem($db, $_GET['id']);
        } elseif (isset($_GET['category'])) {
            getMenuByCategory($db, $_GET['category']);
        } else {
            getAllMenuItems($db);
        }
        break;
    
    case 'POST':
        createMenuItem($db);
        break;
    
    case 'PUT':
        updateMenuItem($db);
        break;
    
    case 'DELETE':
        deleteMenuItem($db);
        break;
    
    default:
        http_response_code(405);
        echo json_encode(array("message" => "Method not allowed"));
        break;
}

function getAllMenuItems($db) {
    $query = "SELECT * FROM cafe_items WHERE is_available = 1 ORDER BY category, name";
    $stmt = $db->prepare($query);
    $stmt->execute();
    
    $items = $stmt->fetchAll();
    echo json_encode($items);
}

function getMenuItem($db, $id) {
    $query = "SELECT * FROM cafe_items WHERE id = :id";
    $stmt = $db->prepare($query);
    $stmt->bindParam(':id', $id);
    $stmt->execute();
    
    $item = $stmt->fetch();
    if ($item) {
        echo json_encode($item);
    } else {
        http_response_code(404);
        echo json_encode(array("message" => "Menu item not found"));
    }
}

function getMenuByCategory($db, $category) {
    $query = "SELECT * FROM cafe_items WHERE category = :category AND is_available = 1 ORDER BY name";
    $stmt = $db->prepare($query);
    $stmt->bindParam(':category', $category);
    $stmt->execute();
    
    $items = $stmt->fetchAll();
    echo json_encode($items);
}

function createMenuItem($db) {
    $data = json_decode(file_get_contents("php://input"));
    
    if (!empty($data->name) && !empty($data->price) && !empty($data->category)) {
        $query = "INSERT INTO cafe_items (name, description, price, category, image_url, is_available) 
                  VALUES (:name, :description, :price, :category, :image_url, :is_available)";
        $stmt = $db->prepare($query);
        
        $stmt->bindParam(':name', $data->name);
        $stmt->bindParam(':description', $data->description);
        $stmt->bindParam(':price', $data->price);
        $stmt->bindParam(':category', $data->category);
        $stmt->bindParam(':image_url', $data->image_url);
        $stmt->bindParam(':is_available', $data->is_available);
        
        if ($stmt->execute()) {
            http_response_code(201);
            echo json_encode(array("message" => "Menu item created successfully", "id" => $db->lastInsertId()));
        } else {
            http_response_code(503);
            echo json_encode(array("message" => "Unable to create menu item"));
        }
    } else {
        http_response_code(400);
        echo json_encode(array("message" => "Unable to create menu item. Data is incomplete"));
    }
}

function updateMenuItem($db) {
    $data = json_decode(file_get_contents("php://input"));
    
    if (!empty($data->id)) {
        $query = "UPDATE cafe_items SET name = :name, description = :description, price = :price, 
                  category = :category, image_url = :image_url, is_available = :is_available WHERE id = :id";
        $stmt = $db->prepare($query);
        
        $stmt->bindParam(':id', $data->id);
        $stmt->bindParam(':name', $data->name);
        $stmt->bindParam(':description', $data->description);
        $stmt->bindParam(':price', $data->price);
        $stmt->bindParam(':category', $data->category);
        $stmt->bindParam(':image_url', $data->image_url);
        $stmt->bindParam(':is_available', $data->is_available);
        
        if ($stmt->execute()) {
            echo json_encode(array("message" => "Menu item updated successfully"));
        } else {
            http_response_code(503);
            echo json_encode(array("message" => "Unable to update menu item"));
        }
    } else {
        http_response_code(400);
        echo json_encode(array("message" => "Unable to update menu item. Data is incomplete"));
    }
}

function deleteMenuItem($db) {
    $data = json_decode(file_get_contents("php://input"));
    
    if (!empty($data->id)) {
        $query = "DELETE FROM cafe_items WHERE id = :id";
        $stmt = $db->prepare($query);
        $stmt->bindParam(':id', $data->id);
        
        if ($stmt->execute()) {
            echo json_encode(array("message" => "Menu item deleted successfully"));
        } else {
            http_response_code(503);
            echo json_encode(array("message" => "Unable to delete menu item"));
        }
    } else {
        http_response_code(400);
        echo json_encode(array("message" => "Unable to delete menu item. Data is incomplete"));
    }
}
?>
