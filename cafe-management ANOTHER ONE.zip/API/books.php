<?php
require_once '../config/database.php';

$database = new Database();
$db = $database->getConnection();

$method = $_SERVER['REQUEST_METHOD'];

switch($method) {
    case 'GET':
        if (isset($_GET['id'])) {
            getBook($db, $_GET['id']);
        } elseif (isset($_GET['genre'])) {
            getBooksByGenre($db, $_GET['genre']);
        } else {
            getAllBooks($db);
        }
        break;
    
    case 'POST':
        createBook($db);
        break;
    
    case 'PUT':
        updateBook($db);
        break;
    
    case 'DELETE':
        deleteBook($db);
        break;
    
    default:
        http_response_code(405);
        echo json_encode(array("message" => "Method not allowed"));
        break;
}

function getAllBooks($db) {
    $query = "SELECT * FROM books WHERE is_available = 1 ORDER BY genre, title";
    $stmt = $db->prepare($query);
    $stmt->execute();
    
    $books = $stmt->fetchAll();
    echo json_encode($books);
}

function getBook($db, $id) {
    $query = "SELECT * FROM books WHERE id = :id";
    $stmt = $db->prepare($query);
    $stmt->bindParam(':id', $id);
    $stmt->execute();
    
    $book = $stmt->fetch();
    if ($book) {
        echo json_encode($book);
    } else {
        http_response_code(404);
        echo json_encode(array("message" => "Book not found"));
    }
}

function getBooksByGenre($db, $genre) {
    $query = "SELECT * FROM books WHERE genre = :genre AND is_available = 1 ORDER BY title";
    $stmt = $db->prepare($query);
    $stmt->bindParam(':genre', $genre);
    $stmt->execute();
    
    $books = $stmt->fetchAll();
    echo json_encode($books);
}

function createBook($db) {
    $data = json_decode(file_get_contents("php://input"));
    
    if (!empty($data->title) && !empty($data->author)) {
        $query = "INSERT INTO books (title, author, isbn, genre, price, is_available) 
                  VALUES (:title, :author, :isbn, :genre, :price, :is_available)";
        $stmt = $db->prepare($query);
        
        $stmt->bindParam(':title', $data->title);
        $stmt->bindParam(':author', $data->author);
        $stmt->bindParam(':isbn', $data->isbn);
        $stmt->bindParam(':genre', $data->genre);
        $stmt->bindParam(':price', $data->price);
        $stmt->bindParam(':is_available', $data->is_available);
        
        if ($stmt->execute()) {
            http_response_code(201);
            echo json_encode(array("message" => "Book created successfully", "id" => $db->lastInsertId()));
        } else {
            http_response_code(503);
            echo json_encode(array("message" => "Unable to create book"));
        }
    } else {
        http_response_code(400);
        echo json_encode(array("message" => "Unable to create book. Data is incomplete"));
    }
}

function updateBook($db) {
    $data = json_decode(file_get_contents("php://input"));
    
    if (!empty($data->id)) {
        $query = "UPDATE books SET title = :title, author = :author, isbn = :isbn, 
                  genre = :genre, price = :price, is_available = :is_available WHERE id = :id";
        $stmt = $db->prepare($query);
        
        $stmt->bindParam(':id', $data->id);
        $stmt->bindParam(':title', $data->title);
        $stmt->bindParam(':author', $data->author);
        $stmt->bindParam(':isbn', $data->isbn);
        $stmt->bindParam(':genre', $data->genre);
        $stmt->bindParam(':price', $data->price);
        $stmt->bindParam(':is_available', $data->is_available);
        
        if ($stmt->execute()) {
            echo json_encode(array("message" => "Book updated successfully"));
        } else {
            http_response_code(503);
            echo json_encode(array("message" => "Unable to update book"));
        }
    } else {
        http_response_code(400);
        echo json_encode(array("message" => "Unable to update book. Data is incomplete"));
    }
}

function deleteBook($db) {
    $data = json_decode(file_get_contents("php://input"));
    
    if (!empty($data->id)) {
        $query = "DELETE FROM books WHERE id = :id";
        $stmt = $db->prepare($query);
        $stmt->bindParam(':id', $data->id);
        
        if ($stmt->execute()) {
            echo json_encode(array("message" => "Book deleted successfully"));
        } else {
            http_response_code(503);
            echo json_encode(array("message" => "Unable to delete book"));
        }
    } else {
        http_response_code(400);
        echo json_encode(array("message" => "Unable to delete book. Data is incomplete"));
    }
}
?>
