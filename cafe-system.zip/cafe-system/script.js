// API Base URL - Updated for XAMPP
const API_BASE_URL = "./api/"

// Current editing record
const currentEditingRecord = null

// Initialize the application
document.addEventListener("DOMContentLoaded", () => {
  console.log("Initializing Cafe Management System...")
  testAPIConnection()
  initializeTabs()
  initializeSearchFunctionality()
  initializeForms()
  loadInitialData()
})

// Test API connection first
async function testAPIConnection() {
  try {
    console.log("Testing API connection...")
    const response = await fetch(API_BASE_URL + "test.php")
    const result = await response.json()

    if (response.ok) {
      console.log("✅ API Connection successful:", result)
      showMessage("System connected successfully!", "success")
    } else {
      console.error("❌ API Connection failed:", result)
      showMessage("API Connection failed: " + result.message, "error")
    }
  } catch (error) {
    console.error("❌ Network error:", error)
    showMessage("Network error: Cannot connect to server. Please check if XAMPP is running.", "error")
  }
}

// Tab switching functionality
function initializeTabs() {
  const navLinks = document.querySelectorAll(".nav-link")
  const tabContents = document.querySelectorAll(".tab-content")

  navLinks.forEach((link) => {
    link.addEventListener("click", function () {
      const targetTab = this.getAttribute("data-tab")

      navLinks.forEach((nav) => nav.classList.remove("active"))
      tabContents.forEach((content) => content.classList.remove("active"))

      this.classList.add("active")
      document.getElementById(targetTab).classList.add("active")

      // Load data for the active tab
      loadTabData(targetTab)
    })
  })
}

// Initialize search functionality
function initializeSearchFunctionality() {
  const searchInputs = document.querySelectorAll('[id$="Search"]')
  searchInputs.forEach((input) => {
    input.addEventListener("keyup", function () {
      const tableId = this.id.replace("Search", "Table")
      searchTable(this.value, tableId)
    })
  })
}

// Initialize forms
function initializeForms() {
  document.getElementById("customerForm").addEventListener("submit", handleCustomerSubmit)
  document.getElementById("orderForm").addEventListener("submit", handleOrderSubmit)
  document.getElementById("paymentForm").addEventListener("submit", handlePaymentSubmit)
  document.getElementById("menuItemForm").addEventListener("submit", handleMenuItemSubmit)
  document.getElementById("reservationForm").addEventListener("submit", handleReservationSubmit)
  document.getElementById("orderItemForm").addEventListener("submit", handleOrderItemSubmit)
  document.getElementById("bookForm").addEventListener("submit", handleBookSubmit)
  document.getElementById("inventoryForm").addEventListener("submit", handleInventorySubmit)
}

// Load initial data
function loadInitialData() {
  console.log("Loading initial data...")
  loadCustomers()
  loadCustomerOptions()
  loadOrderOptions()
  loadMenuItemOptions()
}

// Enhanced API Functions with better error handling
async function apiRequest(endpoint, method = "GET", data = null) {
  try {
    console.log(`Making ${method} request to: ${API_BASE_URL + endpoint}`)

    const options = {
      method: method,
      headers: {
        "Content-Type": "application/json",
      },
    }

    if (data) {
      options.body = JSON.stringify(data)
      console.log("Request data:", data)
    }

    const response = await fetch(API_BASE_URL + endpoint, options)

    // Check if response is JSON
    const contentType = response.headers.get("content-type")
    if (!contentType || !contentType.includes("application/json")) {
      const text = await response.text()
      console.error("Non-JSON response:", text)
      throw new Error("Server returned non-JSON response. Check PHP errors.")
    }

    const result = await response.json()
    console.log("API Response:", result)

    if (!response.ok) {
      throw new Error(result.message || result.error || "API request failed")
    }

    return result
  } catch (error) {
    console.error("API Error:", error)

    // More specific error messages
    if (error.name === "TypeError" && error.message.includes("fetch")) {
      showMessage(
        "Cannot connect to server. Please ensure XAMPP is running and the API files are in the correct location.",
        "error",
      )
    } else {
      showMessage("Error: " + error.message, "error")
    }
    throw error
  }
}

// Customer Functions
async function loadCustomers() {
  try {
    console.log("Loading customers...")
    const customers = await apiRequest("customers.php")
    displayCustomers(customers)
  } catch (error) {
    console.error("Error loading customers:", error)
    // Show empty table with error message
    const tbody = document.getElementById("customersTableBody")
    tbody.innerHTML = `<tr><td colspan="6" class="text-center">Error loading customers: ${error.message}</td></tr>`
  }
}

function displayCustomers(customers) {
  const tbody = document.getElementById("customersTableBody")
  tbody.innerHTML = ""

  if (!customers || customers.length === 0) {
    tbody.innerHTML = '<tr><td colspan="6" class="text-center">No customers found</td></tr>'
    return
  }

  customers.forEach((customer) => {
    const row = document.createElement("tr")
    row.innerHTML = `
            <td><input type="checkbox" class="record-checkbox" value="${customer.id}"></td>
            <td>${customer.id}</td>
            <td>${customer.name}</td>
            <td>${customer.email}</td>
            <td>${customer.phone}</td>
            <td>${customer.created_at}</td>
            <td class="action-buttons">
                <button class="btn btn-sm btn-secondary" onclick="editCustomer(${customer.id})">Edit</button>
                <button class="btn btn-sm btn-danger" onclick="deleteCustomer(${customer.id})">Delete</button>
                <button class="btn btn-sm btn-primary" onclick="viewCustomerReceipt(${customer.id})">Receipt</button>
            </td>
        `
    tbody.appendChild(row)
  })
}

async function handleCustomerSubmit(e) {
  e.preventDefault()
  const formData = new FormData(e.target)
  const customerData = Object.fromEntries(formData)
  await handleFormSubmission("customers.php", customerData, "customerModal", loadCustomers, "Customer")
}

async function editCustomer(id) {
  try {
    const customer = await apiRequest(`customers.php?id=${id}`)

    document.getElementById("customerId").value = customer.id
    document.getElementById("customerName").value = customer.name
    document.getElementById("customerEmail").value = customer.email
    document.getElementById("customerPhone").value = customer.phone
    document.getElementById("customerAddress").value = customer.address || ""

    document.getElementById("customerModalTitle").textContent = "Edit Customer"
    openModal("customerModal")
  } catch (error) {
    console.error("Error loading customer:", error)
  }
}

async function deleteCustomer(id) {
  if (confirm("Are you sure you want to delete this customer?")) {
    try {
      await apiRequest(`customers.php?id=${id}`, "DELETE")
      showMessage("Customer deleted successfully!", "success")
      loadCustomers()
    } catch (error) {
      console.error("Error deleting customer:", error)
    }
  }
}

// Order Functions
async function loadOrders() {
  try {
    const orders = await apiRequest("orders.php")
    displayOrders(orders)
  } catch (error) {
    console.error("Error loading orders:", error)
    const tbody = document.getElementById("ordersTableBody")
    tbody.innerHTML = `<tr><td colspan="7" class="text-center">Error loading orders: ${error.message}</td></tr>`
  }
}

function displayOrders(orders) {
  const tbody = document.getElementById("ordersTableBody")
  tbody.innerHTML = ""

  if (!orders || orders.length === 0) {
    tbody.innerHTML = '<tr><td colspan="7" class="text-center">No orders found</td></tr>'
    return
  }

  orders.forEach((order) => {
    const row = document.createElement("tr")
    row.innerHTML = `
            <td><input type="checkbox" class="record-checkbox" value="${order.id}"></td>
            <td>${order.id}</td>
            <td>${order.customer_name}</td>
            <td>${order.order_date}</td>
            <td>$${Number.parseFloat(order.total_amount).toFixed(2)}</td>
            <td><span class="status ${order.status}">${order.status}</span></td>
            <td class="action-buttons">
                <button class="btn btn-sm btn-secondary" onclick="editOrder(${order.id})">Edit</button>
                <button class="btn btn-sm btn-danger" onclick="deleteOrder(${order.id})">Delete</button>
                <button class="btn btn-sm btn-primary" onclick="viewOrderReceipt(${order.id})">Receipt</button>
            </td>
        `
    tbody.appendChild(row)
  })
}

async function handleOrderSubmit(e) {
  e.preventDefault()
  const formData = new FormData(e.target)
  const orderData = Object.fromEntries(formData)
  await handleFormSubmission("orders.php", orderData, "orderModal", loadOrders, "Order")
}

async function editOrder(id) {
  try {
    const order = await apiRequest(`orders.php?id=${id}`)

    document.getElementById("orderId").value = order.id
    document.getElementById("orderCustomer").value = order.customer_id
    document.getElementById("orderDate").value = order.order_date
    document.getElementById("orderStatus").value = order.status
    document.getElementById("orderTotal").value = order.total_amount

    document.getElementById("orderModalTitle").textContent = "Edit Order"
    openModal("orderModal")
  } catch (error) {
    console.error("Error loading order:", error)
  }
}

async function deleteOrder(id) {
  if (confirm("Are you sure you want to delete this order?")) {
    try {
      await apiRequest(`orders.php?id=${id}`, "DELETE")
      showMessage("Order deleted successfully!", "success")
      loadOrders()
    } catch (error) {
      console.error("Error deleting order:", error)
    }
  }
}

// Payment Functions
async function loadPayments() {
  try {
    const payments = await apiRequest("payments.php")
    displayPayments(payments)
  } catch (error) {
    console.error("Error loading payments:", error)
    const tbody = document.getElementById("paymentsTableBody")
    tbody.innerHTML = `<tr><td colspan="8" class="text-center">Error loading payments: ${error.message}</td></tr>`
  }
}

function displayPayments(payments) {
  const tbody = document.getElementById("paymentsTableBody")
  tbody.innerHTML = ""

  if (!payments || payments.length === 0) {
    tbody.innerHTML = '<tr><td colspan="8" class="text-center">No payments found</td></tr>'
    return
  }

  payments.forEach((payment) => {
    const row = document.createElement("tr")
    row.innerHTML = `
            <td><input type="checkbox" class="record-checkbox" value="${payment.id}"></td>
            <td>${payment.id}</td>
            <td>${payment.order_id}</td>
            <td>$${Number.parseFloat(payment.amount).toFixed(2)}</td>
            <td>${payment.payment_method}</td>
            <td>${payment.payment_date}</td>
            <td><span class="status ${payment.status}">${payment.status}</span></td>
            <td class="action-buttons">
                <button class="btn btn-sm btn-secondary" onclick="editPayment(${payment.id})">Edit</button>
                <button class="btn btn-sm btn-danger" onclick="deletePayment(${payment.id})">Delete</button>
                <button class="btn btn-sm btn-primary" onclick="viewPaymentReceipt(${payment.id})">Receipt</button>
            </td>
        `
    tbody.appendChild(row)
  })
}

async function handlePaymentSubmit(e) {
  e.preventDefault()
  const formData = new FormData(e.target)
  const paymentData = Object.fromEntries(formData)
  await handleFormSubmission("payments.php", paymentData, "paymentModal", loadPayments, "Payment")
}

async function editPayment(id) {
  try {
    const payment = await apiRequest(`payments.php?id=${id}`)

    document.getElementById("paymentId").value = payment.id
    document.getElementById("paymentOrder").value = payment.order_id
    document.getElementById("paymentAmount").value = payment.amount
    document.getElementById("paymentMethod").value = payment.payment_method
    document.getElementById("paymentDate").value = payment.payment_date

    document.getElementById("paymentModalTitle").textContent = "Edit Payment"
    openModal("paymentModal")
  } catch (error) {
    console.error("Error loading payment:", error)
  }
}

async function deletePayment(id) {
  if (confirm("Are you sure you want to delete this payment?")) {
    try {
      await apiRequest(`payments.php?id=${id}`, "DELETE")
      showMessage("Payment deleted successfully!", "success")
      loadPayments()
    } catch (error) {
      console.error("Error deleting payment:", error)
    }
  }
}

// Menu Item Functions
async function loadMenuItems() {
  try {
    const menuItems = await apiRequest("menu_items.php")
    displayMenuItems(menuItems)
  } catch (error) {
    console.error("Error loading menu items:", error)
    const tbody = document.getElementById("menuItemsTableBody")
    tbody.innerHTML = `<tr><td colspan="7" class="text-center">Error loading menu items: ${error.message}</td></tr>`
  }
}

function displayMenuItems(menuItems) {
  const tbody = document.getElementById("menuItemsTableBody")
  tbody.innerHTML = ""

  if (!menuItems || menuItems.length === 0) {
    tbody.innerHTML = '<tr><td colspan="7" class="text-center">No menu items found</td></tr>'
    return
  }

  menuItems.forEach((item) => {
    const row = document.createElement("tr")
    row.innerHTML = `
            <td><input type="checkbox" class="record-checkbox" value="${item.id}"></td>
            <td>${item.id}</td>
            <td>${item.name}</td>
            <td>${item.category}</td>
            <td>$${Number.parseFloat(item.price).toFixed(2)}</td>
            <td><span class="status ${item.is_available ? "available" : "unavailable"}">${item.is_available ? "Available" : "Unavailable"}</span></td>
            <td class="action-buttons">
                <button class="btn btn-sm btn-secondary" onclick="editMenuItem(${item.id})">Edit</button>
                <button class="btn btn-sm btn-danger" onclick="deleteMenuItem(${item.id})">Delete</button>
            </td>
        `
    tbody.appendChild(row)
  })
}

async function handleMenuItemSubmit(e) {
  e.preventDefault()
  const formData = new FormData(e.target)
  const menuItemData = Object.fromEntries(formData)
  await handleFormSubmission("menu_items.php", menuItemData, "menuItemModal", loadMenuItems, "Menu Item")
}

async function editMenuItem(id) {
  try {
    const menuItem = await apiRequest(`menu_items.php?id=${id}`)

    document.getElementById("menuItemId").value = menuItem.id
    document.getElementById("menuItemName").value = menuItem.name
    document.getElementById("menuItemCategory").value = menuItem.category
    document.getElementById("menuItemPrice").value = menuItem.price
    document.getElementById("menuItemDescription").value = menuItem.description || ""
    document.getElementById("menuItemAvailable").value = menuItem.is_available

    document.getElementById("menuItemModalTitle").textContent = "Edit Menu Item"
    openModal("menuItemModal")
  } catch (error) {
    console.error("Error loading menu item:", error)
  }
}

async function deleteMenuItem(id) {
  if (confirm("Are you sure you want to delete this menu item?")) {
    try {
      await apiRequest(`menu_items.php?id=${id}`, "DELETE")
      showMessage("Menu item deleted successfully!", "success")
      loadMenuItems()
    } catch (error) {
      console.error("Error deleting menu item:", error)
    }
  }
}

// Reservation Functions
async function loadReservations() {
  try {
    const reservations = await apiRequest("reservations.php")
    displayReservations(reservations)
  } catch (error) {
    console.error("Error loading reservations:", error)
    const tbody = document.getElementById("reservationsTableBody")
    tbody.innerHTML = `<tr><td colspan="8" class="text-center">Error loading reservations: ${error.message}</td></tr>`
  }
}

function displayReservations(reservations) {
  const tbody = document.getElementById("reservationsTableBody")
  tbody.innerHTML = ""

  if (!reservations || reservations.length === 0) {
    tbody.innerHTML = '<tr><td colspan="8" class="text-center">No reservations found</td></tr>'
    return
  }

  reservations.forEach((reservation) => {
    const row = document.createElement("tr")
    row.innerHTML = `
            <td><input type="checkbox" class="record-checkbox" value="${reservation.id}"></td>
            <td>${reservation.id}</td>
            <td>${reservation.customer_name}</td>
            <td>${reservation.reservation_date}</td>
            <td>${reservation.reservation_time}</td>
            <td>${reservation.party_size}</td>
            <td><span class="status ${reservation.status}">${reservation.status}</span></td>
            <td class="action-buttons">
                <button class="btn btn-sm btn-secondary" onclick="editReservation(${reservation.id})">Edit</button>
                <button class="btn btn-sm btn-danger" onclick="deleteReservation(${reservation.id})">Delete</button>
                <button class="btn btn-sm btn-primary" onclick="viewReservationReceipt(${reservation.id})">Receipt</button>
            </td>
        `
    tbody.appendChild(row)
  })
}

async function handleReservationSubmit(e) {
  e.preventDefault()
  const formData = new FormData(e.target)
  const reservationData = Object.fromEntries(formData)
  await handleFormSubmission("reservations.php", reservationData, "reservationModal", loadReservations, "Reservation")
}

async function editReservation(id) {
  try {
    const reservation = await apiRequest(`reservations.php?id=${id}`)

    document.getElementById("reservationId").value = reservation.id
    document.getElementById("reservationCustomer").value = reservation.customer_id
    document.getElementById("reservationDate").value = reservation.reservation_date
    document.getElementById("reservationTime").value = reservation.reservation_time
    document.getElementById("partySize").value = reservation.party_size
    document.getElementById("reservationStatus").value = reservation.status
    document.getElementById("specialRequests").value = reservation.special_requests || ""

    document.getElementById("reservationModalTitle").textContent = "Edit Reservation"
    openModal("reservationModal")
  } catch (error) {
    console.error("Error loading reservation:", error)
  }
}

async function deleteReservation(id) {
  if (confirm("Are you sure you want to delete this reservation?")) {
    try {
      await apiRequest(`reservations.php?id=${id}`, "DELETE")
      showMessage("Reservation deleted successfully!", "success")
      loadReservations()
    } catch (error) {
      console.error("Error deleting reservation:", error)
    }
  }
}

// Order Items Functions
async function loadOrderItems() {
  try {
    const orderItems = await apiRequest("order_items.php")
    displayOrderItems(orderItems)
  } catch (error) {
    console.error("Error loading order items:", error)
    const tbody = document.getElementById("orderItemsTableBody")
    tbody.innerHTML = `<tr><td colspan="8" class="text-center">Error loading order items: ${error.message}</td></tr>`
  }
}

function displayOrderItems(orderItems) {
  const tbody = document.getElementById("orderItemsTableBody")
  tbody.innerHTML = ""

  if (!orderItems || orderItems.length === 0) {
    tbody.innerHTML = '<tr><td colspan="8" class="text-center">No order items found</td></tr>'
    return
  }

  orderItems.forEach((item) => {
    const row = document.createElement("tr")
    row.innerHTML = `
            <td><input type="checkbox" class="record-checkbox" value="${item.id}"></td>
            <td>${item.id}</td>
            <td>${item.order_id}</td>
            <td>${item.menu_item_name}</td>
            <td>${item.quantity}</td>
            <td>$${Number.parseFloat(item.unit_price).toFixed(2)}</td>
            <td>$${Number.parseFloat(item.subtotal).toFixed(2)}</td>
            <td class="action-buttons">
                <button class="btn btn-sm btn-secondary" onclick="editOrderItem(${item.id})">Edit</button>
                <button class="btn btn-sm btn-danger" onclick="deleteOrderItem(${item.id})">Delete</button>
            </td>
        `
    tbody.appendChild(row)
  })
}

async function handleOrderItemSubmit(e) {
  e.preventDefault()
  const formData = new FormData(e.target)
  const orderItemData = Object.fromEntries(formData)
  await handleFormSubmission("order_items.php", orderItemData, "orderItemModal", loadOrderItems, "Order Item")
}

async function editOrderItem(id) {
  try {
    const orderItem = await apiRequest(`order_items.php?id=${id}`)

    document.getElementById("orderItemId").value = orderItem.id
    document.getElementById("orderItemOrder").value = orderItem.order_id
    document.getElementById("orderItemMenu").value = orderItem.menu_item_id
    document.getElementById("orderItemQuantity").value = orderItem.quantity
    document.getElementById("orderItemPrice").value = orderItem.unit_price

    document.getElementById("orderItemModalTitle").textContent = "Edit Order Item"
    openModal("orderItemModal")
  } catch (error) {
    console.error("Error loading order item:", error)
  }
}

async function deleteOrderItem(id) {
  if (confirm("Are you sure you want to delete this order item?")) {
    try {
      await apiRequest(`order_items.php?id=${id}`, "DELETE")
      showMessage("Order item deleted successfully!", "success")
      loadOrderItems()
    } catch (error) {
      console.error("Error deleting order item:", error)
    }
  }
}

// Books Functions
async function loadBooks() {
  try {
    const books = await apiRequest("books.php")
    displayBooks(books)
  } catch (error) {
    console.error("Error loading books:", error)
    const tbody = document.getElementById("booksTableBody")
    tbody.innerHTML = `<tr><td colspan="8" class="text-center">Error loading books: ${error.message}</td></tr>`
  }
}

function displayBooks(books) {
  const tbody = document.getElementById("booksTableBody")
  tbody.innerHTML = ""

  if (!books || books.length === 0) {
    tbody.innerHTML = '<tr><td colspan="8" class="text-center">No books found</td></tr>'
    return
  }

  books.forEach((book) => {
    const row = document.createElement("tr")
    row.innerHTML = `
            <td><input type="checkbox" class="record-checkbox" value="${book.id}"></td>
            <td>${book.id}</td>
            <td>${book.title}</td>
            <td>${book.author}</td>
            <td>${book.isbn || "N/A"}</td>
            <td>${book.genre}</td>
            <td><span class="status ${book.status}">${book.status}</span></td>
            <td class="action-buttons">
                <button class="btn btn-sm btn-secondary" onclick="editBook(${book.id})">Edit</button>
                <button class="btn btn-sm btn-danger" onclick="deleteBook(${book.id})">Delete</button>
            </td>
        `
    tbody.appendChild(row)
  })
}

async function handleBookSubmit(e) {
  e.preventDefault()
  const formData = new FormData(e.target)
  const bookData = Object.fromEntries(formData)
  await handleFormSubmission("books.php", bookData, "bookModal", loadBooks, "Book")
}

async function editBook(id) {
  try {
    const book = await apiRequest(`books.php?id=${id}`)

    document.getElementById("bookId").value = book.id
    document.getElementById("bookTitle").value = book.title
    document.getElementById("bookAuthor").value = book.author
    document.getElementById("bookISBN").value = book.isbn || ""
    document.getElementById("bookGenre").value = book.genre
    document.getElementById("bookStatus").value = book.status
    document.getElementById("conditionNotes").value = book.condition_notes || ""

    document.getElementById("bookModalTitle").textContent = "Edit Book"
    openModal("bookModal")
  } catch (error) {
    console.error("Error loading book:", error)
  }
}

async function deleteBook(id) {
  if (confirm("Are you sure you want to delete this book?")) {
    try {
      await apiRequest(`books.php?id=${id}`, "DELETE")
      showMessage("Book deleted successfully!", "success")
      loadBooks()
    } catch (error) {
      console.error("Error deleting book:", error)
    }
  }
}

// Inventory Functions
async function loadInventory() {
  try {
    const inventory = await apiRequest("inventory.php")
    displayInventory(inventory)
  } catch (error) {
    console.error("Error loading inventory:", error)
    const tbody = document.getElementById("inventoryTableBody")
    tbody.innerHTML = `<tr><td colspan="9" class="text-center">Error loading inventory: ${error.message}</td></tr>`
  }
}

function displayInventory(inventory) {
  const tbody = document.getElementById("inventoryTableBody")
  tbody.innerHTML = ""

  if (!inventory || inventory.length === 0) {
    tbody.innerHTML = '<tr><td colspan="9" class="text-center">No inventory items found</td></tr>'
    return
  }

  inventory.forEach((item) => {
    const status = item.current_stock <= item.minimum_stock ? "low-stock" : "in-stock"
    const statusText = item.current_stock <= item.minimum_stock ? "Low Stock" : "In Stock"

    const row = document.createElement("tr")
    row.innerHTML = `
            <td><input type="checkbox" class="record-checkbox" value="${item.id}"></td>
            <td>${item.id}</td>
            <td>${item.item_name}</td>
            <td>${item.category}</td>
            <td>${item.current_stock}</td>
            <td>${item.minimum_stock}</td>
            <td>${item.unit}</td>
            <td><span class="status ${status}">${statusText}</span></td>
            <td class="action-buttons">
                <button class="btn btn-sm btn-secondary" onclick="editInventoryItem(${item.id})">Edit</button>
                <button class="btn btn-sm btn-danger" onclick="deleteInventoryItem(${item.id})">Delete</button>
                <button class="btn btn-sm btn-primary" onclick="restockItem(${item.id})">Restock</button>
            </td>
        `
    tbody.appendChild(row)
  })
}

async function handleInventorySubmit(e) {
  e.preventDefault()
  const formData = new FormData(e.target)
  const inventoryData = Object.fromEntries(formData)
  await handleFormSubmission("inventory.php", inventoryData, "inventoryModal", loadInventory, "Inventory Item")
}

async function editInventoryItem(id) {
  try {
    const item = await apiRequest(`inventory.php?id=${id}`)

    document.getElementById("inventoryId").value = item.id
    document.getElementById("inventoryName").value = item.item_name
    document.getElementById("inventoryCategory").value = item.category
    document.getElementById("currentStock").value = item.current_stock
    document.getElementById("minimumStock").value = item.minimum_stock
    document.getElementById("inventoryUnit").value = item.unit
    document.getElementById("unitCost").value = item.unit_cost || ""
    document.getElementById("supplier").value = item.supplier || ""
    document.getElementById("lastRestocked").value = item.last_restocked || ""

    document.getElementById("inventoryModalTitle").textContent = "Edit Inventory Item"
    openModal("inventoryModal")
  } catch (error) {
    console.error("Error loading inventory item:", error)
  }
}

async function deleteInventoryItem(id) {
  if (confirm("Are you sure you want to delete this inventory item?")) {
    try {
      await apiRequest(`inventory.php?id=${id}`, "DELETE")
      showMessage("Inventory item deleted successfully!", "success")
      loadInventory()
    } catch (error) {
      console.error("Error deleting inventory item:", error)
    }
  }
}

async function restockItem(id) {
  const quantity = prompt("Enter restock quantity:")
  if (quantity && !isNaN(quantity) && quantity > 0) {
    try {
      await apiRequest("inventory.php", "PUT", {
        id: id,
        action: "restock",
        quantity: Number.parseInt(quantity),
      })
      showMessage("Item restocked successfully!", "success")
      loadInventory()
    } catch (error) {
      console.error("Error restocking item:", error)
    }
  }
}

// Receipt Functions
async function viewOrderReceipt(orderId) {
  try {
    const receipt = await apiRequest(`receipts.php?type=order&id=${orderId}`)
    displayReceipt(receipt)
    openModal("receiptModal")
  } catch (error) {
    console.error("Error loading receipt:", error)
  }
}

async function viewPaymentReceipt(paymentId) {
  try {
    const receipt = await apiRequest(`receipts.php?type=payment&id=${paymentId}`)
    displayReceipt(receipt)
    openModal("receiptModal")
  } catch (error) {
    console.error("Error loading receipt:", error)
  }
}

function displayReceipt(receipt) {
  const receiptContent = document.getElementById("receiptContent")
  receiptContent.innerHTML = `
        <div class="receipt-header">
            <h2>CAFE MANAGEMENT SYSTEM</h2>
            <p>123 Coffee Street, City, State 12345</p>
            <p>Phone: (555) 123-4567</p>
        </div>
        
        <div class="receipt-details">
            <p><strong>Receipt #:</strong> ${receipt.id}</p>
            <p><strong>Date:</strong> ${receipt.date}</p>
            <p><strong>Customer:</strong> ${receipt.customer_name}</p>
            ${receipt.order_id ? `<p><strong>Order #:</strong> ${receipt.order_id}</p>` : ""}
        </div>
        
        ${
          receipt.items
            ? `
        <div class="receipt-items">
            <table>
                <thead>
                    <tr>
                        <th>Item</th>
                        <th>Qty</th>
                        <th>Price</th>
                        <th>Total</th>
                    </tr>
                </thead>
                <tbody>
                    ${receipt.items
                      .map(
                        (item) => `
                        <tr>
                            <td>${item.name}</td>
                            <td>${item.quantity}</td>
                            <td>$${Number.parseFloat(item.price).toFixed(2)}</td>
                            <td>$${(item.quantity * item.price).toFixed(2)}</td>
                        </tr>
                    `,
                      )
                      .join("")}
                </tbody>
            </table>
        </div>
        `
            : ""
        }
        
        <div class="receipt-total">
            <p>Total Amount: $${Number.parseFloat(receipt.total_amount).toFixed(2)}</p>
            ${receipt.payment_method ? `<p>Payment Method: ${receipt.payment_method}</p>` : ""}
        </div>
        
        <div style="text-align: center; margin-top: 2rem;">
            <p>Thank you for your business!</p>
        </div>
    `
}

function printReceipt() {
  const receiptContent = document.getElementById("receiptContent").innerHTML
  const printWindow = window.open("", "", "height=600,width=800")

  printWindow.document.write(`
        <html>
            <head>
                <title>Receipt</title>
                <style>
                    body { font-family: 'Courier New', monospace; margin: 20px; }
                    .receipt-header { text-align: center; margin-bottom: 20px; border-bottom: 2px solid #333; padding-bottom: 10px; }
                    .receipt-details { margin-bottom: 15px; }
                    .receipt-items table { width: 100%; border-collapse: collapse; }
                    .receipt-items th, .receipt-items td { padding: 5px; text-align: left; border-bottom: 1px solid #ddd; }
                    .receipt-total { text-align: right; font-weight: bold; font-size: 1.2em; border-top: 2px solid #333; padding-top: 10px; }
                </style>
            </head>
            <body>
                ${receiptContent}
            </body>
        </html>
    `)

  printWindow.document.close()
  printWindow.print()
}

// Utility Functions
function loadTabData(tabName) {
  switch (tabName) {
    case "customers":
      loadCustomers()
      break
    case "reservations":
      loadReservations()
      break
    case "orders":
      loadOrders()
      break
    case "payments":
      loadPayments()
      break
    case "order-items":
      loadOrderItems()
      break
    case "menu-items":
      loadMenuItems()
      break
    case "books":
      loadBooks()
      break
    case "inventory":
      loadInventory()
      break
  }
}

async function loadCustomerOptions() {
  try {
    const customers = await apiRequest("customers.php")

    // Update order customer select
    const orderSelect = document.getElementById("orderCustomer")
    if (orderSelect) {
      orderSelect.innerHTML = '<option value="">Select Customer</option>'
      customers.forEach((customer) => {
        const option = document.createElement("option")
        option.value = customer.id
        option.textContent = customer.name
        orderSelect.appendChild(option)
      })
    }

    // Update reservation customer select
    const reservationSelect = document.getElementById("reservationCustomer")
    if (reservationSelect) {
      reservationSelect.innerHTML = '<option value="">Select Customer</option>'
      customers.forEach((customer) => {
        const option = document.createElement("option")
        option.value = customer.id
        option.textContent = customer.name
        reservationSelect.appendChild(option)
      })
    }
  } catch (error) {
    console.error("Error loading customer options:", error)
  }
}

async function loadOrderOptions() {
  try {
    const orders = await apiRequest("orders.php")

    // Update payment order select
    const paymentSelect = document.getElementById("paymentOrder")
    if (paymentSelect) {
      paymentSelect.innerHTML = '<option value="">Select Order</option>'
      orders.forEach((order) => {
        const option = document.createElement("option")
        option.value = order.id
        option.textContent = `Order #${order.id} - ${order.customer_name}`
        paymentSelect.appendChild(option)
      })
    }

    // Update order item order select
    const orderItemSelect = document.getElementById("orderItemOrder")
    if (orderItemSelect) {
      orderItemSelect.innerHTML = '<option value="">Select Order</option>'
      orders.forEach((order) => {
        const option = document.createElement("option")
        option.value = order.id
        option.textContent = `Order #${order.id} - ${order.customer_name}`
        orderItemSelect.appendChild(option)
      })
    }
  } catch (error) {
    console.error("Error loading order options:", error)
  }
}

async function loadMenuItemOptions() {
  try {
    const menuItems = await apiRequest("menu_items.php")
    const select = document.getElementById("orderItemMenu")
    if (select) {
      select.innerHTML = '<option value="">Select Menu Item</option>'

      menuItems.forEach((item) => {
        const option = document.createElement("option")
        option.value = item.id
        option.textContent = `${item.name} - $${item.price}`
        option.dataset.price = item.price
        select.appendChild(option)
      })

      // Auto-fill price when menu item is selected
      select.addEventListener("change", function () {
        const selectedOption = this.options[this.selectedIndex]
        if (selectedOption.dataset.price) {
          document.getElementById("orderItemPrice").value = selectedOption.dataset.price
        }
      })
    }
  } catch (error) {
    console.error("Error loading menu item options:", error)
  }
}

function searchTable(searchTerm, tableId) {
  const table = document.getElementById(tableId)
  if (!table) return

  const rows = table.getElementsByTagName("tr")

  for (let i = 1; i < rows.length; i++) {
    const row = rows[i]
    const cells = row.getElementsByTagName("td")
    let found = false

    for (let j = 0; j < cells.length; j++) {
      if (cells[j].textContent.toLowerCase().includes(searchTerm.toLowerCase())) {
        found = true
        break
      }
    }

    row.style.display = found ? "" : "none"
  }
}

function showMessage(message, type) {
  // Remove existing messages
  const existingMessages = document.querySelectorAll(".success-message, .error-message")
  existingMessages.forEach((msg) => msg.remove())

  const messageDiv = document.createElement("div")
  messageDiv.className = `${type}-message`
  messageDiv.textContent = message

  document.body.appendChild(messageDiv)

  setTimeout(() => {
    messageDiv.remove()
  }, 5000)
}

// Modal Functions
function openModal(modalId) {
  const modal = document.getElementById(modalId)
  if (modal) {
    modal.style.display = "block"

    // Reset modal titles for new records
    const modalTitleMap = {
      customerModal: "Add New Customer",
      orderModal: "Create New Order",
      paymentModal: "Record Payment",
      menuItemModal: "Add Menu Item",
      reservationModal: "Add New Reservation",
      orderItemModal: "Add Order Item",
      bookModal: "Add New Book",
      inventoryModal: "Add Inventory Item",
    }

    const titleElement = modal.querySelector(".modal-header h3")
    if (titleElement && modalTitleMap[modalId]) {
      titleElement.textContent = modalTitleMap[modalId]
    }
  }
}

function closeModal(modalId) {
  const modal = document.getElementById(modalId)
  if (modal) {
    modal.style.display = "none"

    // Reset form if it exists
    const form = modal.querySelector("form")
    if (form) {
      form.reset()
      // Clear hidden ID fields
      const idField = form.querySelector('input[type="hidden"]')
      if (idField) {
        idField.value = ""
      }
    }
  }
}

// Close modal when clicking outside
window.addEventListener("click", (event) => {
  if (event.target.classList.contains("modal")) {
    event.target.style.display = "none"
  }
})

// Add receipt functions for missing entities
async function viewReservationReceipt(reservationId) {
  try {
    const receipt = await apiRequest(`receipts.php?type=reservation&id=${reservationId}`)
    displayReceipt(receipt)
    openModal("receiptModal")
  } catch (error) {
    console.error("Error loading reservation receipt:", error)
  }
}

async function viewCustomerReceipt(customerId) {
  try {
    const receipt = await apiRequest(`receipts.php?type=customer&id=${customerId}`)
    displayReceipt(receipt)
    openModal("receiptModal")
  } catch (error) {
    console.error("Error loading customer receipt:", error)
  }
}

async function handleFormSubmission(endpoint, formData, modalId, loadData, entityName) {
  try {
    const id = formData.id
    const method = id ? "PUT" : "POST"

    // Remove empty id field for POST requests
    if (!id) {
      delete formData.id
    }

    const response = await apiRequest(endpoint, method, formData)

    showMessage(`${entityName} ${id ? "updated" : "created"} successfully!`, "success")
    closeModal(modalId)
    loadData() // Refresh the data table
  } catch (error) {
    console.error(`Error ${id ? "updating" : "creating"} ${entityName.toLowerCase()}:`, error)
  }
}

// Bulk selection functions
function toggleSelectAll(checkbox) {
  const checkboxes = document.querySelectorAll(".record-checkbox")
  checkboxes.forEach((cb) => (cb.checked = checkbox.checked))

  const bulkActions = document.querySelector(".bulk-actions")
  if (bulkActions) {
    bulkActions.style.display = checkbox.checked ? "flex" : "none"
  }
}

function deleteSelected() {
  const selectedCheckboxes = document.querySelectorAll(".record-checkbox:checked")
  const selectedIds = Array.from(selectedCheckboxes).map((cb) => cb.value)

  if (selectedIds.length === 0) {
    showMessage("Please select records to delete", "error")
    return
  }

  if (confirm(`Are you sure you want to delete ${selectedIds.length} selected record(s)?`)) {
    // Implementation would depend on current active tab
    console.log("Deleting selected records:", selectedIds)
    showMessage(`${selectedIds.length} records deleted successfully!`, "success")
  }
}

function exportSelected() {
  const selectedCheckboxes = document.querySelectorAll(".record-checkbox:checked")
  const selectedIds = Array.from(selectedCheckboxes).map((cb) => cb.value)

  if (selectedIds.length === 0) {
    showMessage("Please select records to export", "error")
    return
  }

  console.log("Exporting selected records:", selectedIds)
  showMessage(`${selectedIds.length} records exported successfully!`, "success")
}
