-- Insert sample customers
INSERT INTO customers (name, email, phone, address) VALUES
('John Smith', 'john.smith@email.com', '+1-234-567-8900', '123 Main St, City, State 12345'),
('Sarah Johnson', 'sarah.j@email.com', '+1-234-567-8901', '456 Oak Ave, City, State 12346'),
('Mike Davis', 'mike.davis@email.com', '+1-234-567-8902', '789 Pine Rd, City, State 12347'),
('Emily Brown', 'emily.brown@email.com', '+1-234-567-8903', '321 Elm St, City, State 12348'),
('David Wilson', 'david.wilson@email.com', '+1-234-567-8904', '654 Maple Dr, City, State 12349');

-- Insert sample menu items
INSERT INTO menu_items (name, category, description, price, is_available) VALUES
('Espresso', 'beverages', 'Rich and bold espresso shot', 2.50, TRUE),
('Cappuccino', 'beverages', 'Espresso with steamed milk and foam', 4.50, TRUE),
('Latte', 'beverages', 'Espresso with steamed milk', 4.75, TRUE),
('Americano', 'beverages', 'Espresso with hot water', 3.25, TRUE),
('Mocha', 'beverages', 'Espresso with chocolate and steamed milk', 5.25, TRUE),
('Croissant', 'pastries', 'Buttery, flaky pastry', 3.00, TRUE),
('Chocolate Croissant', 'pastries', 'Croissant filled with chocolate', 3.50, TRUE),
('Blueberry Muffin', 'pastries', 'Fresh baked muffin with blueberries', 2.75, TRUE),
('Club Sandwich', 'sandwiches', 'Turkey, bacon, lettuce, tomato on toasted bread', 8.95, TRUE),
('Caesar Salad', 'salads', 'Romaine lettuce with Caesar dressing and croutons', 7.50, TRUE);

-- Insert sample orders
INSERT INTO orders (customer_id, order_date, total_amount, status) VALUES
(1, '2024-01-25 14:30:00', 9.00, 'completed'),
(2, '2024-01-25 15:45:00', 12.25, 'completed'),
(3, '2024-01-26 09:15:00', 6.75, 'preparing'),
(4, '2024-01-26 11:30:00', 15.50, 'ready'),
(5, '2024-01-26 13:20:00', 8.25, 'pending');

-- Insert sample order items
INSERT INTO order_items (order_id, menu_item_id, quantity, unit_price) VALUES
(1, 2, 2, 4.50), -- 2 Cappuccinos
(2, 3, 1, 4.75), -- 1 Latte
(2, 7, 1, 3.50), -- 1 Chocolate Croissant
(2, 8, 1, 2.75), -- 1 Blueberry Muffin
(3, 1, 1, 2.50), -- 1 Espresso
(3, 6, 1, 3.00), -- 1 Croissant
(4, 9, 1, 8.95), -- 1 Club Sandwich
(4, 3, 1, 4.75), -- 1 Latte
(5, 4, 2, 3.25); -- 2 Americanos

-- Insert sample payments
INSERT INTO payments (order_id, amount, payment_method, payment_date, status) VALUES
(1, 9.00, 'credit_card', '2024-01-25 14:35:00', 'completed'),
(2, 12.25, 'cash', '2024-01-25 15:50:00', 'completed');

-- Insert sample reservations
INSERT INTO reservations (customer_id, reservation_date, reservation_time, party_size, status) VALUES
(1, '2024-01-28', '19:00:00', 4, 'confirmed'),
(3, '2024-01-29', '18:30:00', 2, 'pending'),
(5, '2024-01-30', '20:00:00', 6, 'confirmed');

-- Insert sample books
INSERT INTO books (title, author, isbn, genre, status) VALUES
('The Great Gatsby', 'F. Scott Fitzgerald', '978-0-7432-7356-5', 'Classic Literature', 'available'),
('To Kill a Mockingbird', 'Harper Lee', '978-0-06-112008-4', 'Classic Literature', 'available'),
('1984', 'George Orwell', '978-0-452-28423-4', 'Dystopian Fiction', 'borrowed'),
('Pride and Prejudice', 'Jane Austen', '978-0-14-143951-8', 'Romance', 'available'),
('The Catcher in the Rye', 'J.D. Salinger', '978-0-316-76948-0', 'Coming of Age', 'available');

-- Insert sample inventory
INSERT INTO inventory (item_name, category, current_stock, minimum_stock, unit, unit_cost, supplier, last_restocked) VALUES
('Coffee Beans - Arabica', 'Raw Materials', 25, 10, 'kg', 12.50, 'Premium Coffee Suppliers', '2024-01-20'),
('Milk - Whole', 'Dairy', 15, 20, 'liters', 1.25, 'Local Dairy Farm', '2024-01-24'),
('Sugar - White', 'Sweeteners', 50, 15, 'kg', 2.00, 'Food Distributors Inc', '2024-01-22'),
('Flour - All Purpose', 'Baking', 30, 10, 'kg', 1.80, 'Baking Supplies Co', '2024-01-21'),
('Butter - Unsalted', 'Dairy', 8, 12, 'kg', 4.50, 'Local Dairy Farm', '2024-01-23'),
('Chocolate Chips', 'Baking', 5, 8, 'kg', 6.75, 'Chocolate Suppliers Ltd', '2024-01-19'),
('Paper Cups - 12oz', 'Supplies', 500, 200, 'pieces', 0.15, 'Restaurant Supply Co', '2024-01-25'),
('Napkins', 'Supplies', 1000, 300, 'pieces', 0.05, 'Restaurant Supply Co', '2024-01-25');
