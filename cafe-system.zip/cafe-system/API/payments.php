<?php
require_once 'config.php';

$pdo = getDBConnection();
$method = $_SERVER['REQUEST_METHOD'];

switch ($method) {
    case 'GET':
        if (isset($_GET['id'])) {
            // Get single payment
            $stmt = $pdo->prepare("SELECT * FROM payments WHERE id = ?");
            $stmt->execute([$_GET['id']]);
            $payment = $stmt->fetch();
            
            if ($payment) {
                sendResponse($payment);
            } else {
                sendResponse(['error' => 'Payment not found'], 404);
            }
        } else {
            // Get all payments
            $stmt = $pdo->query("SELECT * FROM payments ORDER BY payment_date DESC");
            $payments = $stmt->fetchAll();
            sendResponse($payments);
        }
        break;

    case 'POST':
        $data = json_decode(file_get_contents('php://input'), true);
        $required = ['order_id', 'amount', 'payment_method', 'payment_date'];
        $missing = validateRequired($data, $required);
        
        if (!empty($missing)) {
            sendResponse(['error' => 'Missing required fields: ' . implode(', ', $missing)], 400);
        }

        try {
            $stmt = $pdo->prepare("INSERT INTO payments (order_id, amount, payment_method, payment_date, status) VALUES (?, ?, ?, ?, 'completed')");
            $stmt->execute([
                $data['order_id'],
                $data['amount'],
                $data['payment_method'],
                $data['payment_date']
            ]);
            
            $id = $pdo->lastInsertId();
            sendResponse(['id' => $id, 'message' => 'Payment recorded successfully'], 201);
        } catch (PDOException $e) {
            sendResponse(['error' => 'Database error: ' . $e->getMessage()], 500);
        }
        break;

    case 'PUT':
        $data = json_decode(file_get_contents('php://input'), true);
        $required = ['id', 'order_id', 'amount', 'payment_method', 'payment_date'];
        $missing = validateRequired($data, $required);
        
        if (!empty($missing)) {
            sendResponse(['error' => 'Missing required fields: ' . implode(', ', $missing)], 400);
        }

        try {
            $stmt = $pdo->prepare("UPDATE payments SET order_id = ?, amount = ?, payment_method = ?, payment_date = ? WHERE id = ?");
            $result = $stmt->execute([
                $data['order_id'],
                $data['amount'],
                $data['payment_method'],
                $data['payment_date'],
                $data['id']
            ]);
            
            if ($stmt->rowCount() > 0) {
                sendResponse(['message' => 'Payment updated successfully']);
            } else {
                sendResponse(['error' => 'Payment not found or no changes made'], 404);
            }
        } catch (PDOException $e) {
            sendResponse(['error' => 'Database error: ' . $e->getMessage()], 500);
        }
        break;

    case 'DELETE':
        if (!isset($_GET['id'])) {
            sendResponse(['error' => 'Payment ID is required'], 400);
        }

        try {
            $stmt = $pdo->prepare("DELETE FROM payments WHERE id = ?");
            $stmt->execute([$_GET['id']]);
            
            if ($stmt->rowCount() > 0) {
                sendResponse(['message' => 'Payment deleted successfully']);
            } else {
                sendResponse(['error' => 'Payment not found'], 404);
            }
        } catch (PDOException $e) {
            sendResponse(['error' => 'Database error: ' . $e->getMessage()], 500);
        }
        break;

    default:
        sendResponse(['error' => 'Method not allowed'], 405);
}
?>
