<?php
require_once 'config.php';

$pdo = getDBConnection();
$method = $_SERVER['REQUEST_METHOD'];

switch ($method) {
    case 'GET':
        if (isset($_GET['id'])) {
            // Get single customer
            $stmt = $pdo->prepare("SELECT * FROM customers WHERE id = ?");
            $stmt->execute([$_GET['id']]);
            $customer = $stmt->fetch();
            
            if ($customer) {
                sendResponse($customer);
            } else {
                sendResponse(['error' => 'Customer not found'], 404);
            }
        } else {
            // Get all customers
            $stmt = $pdo->query("SELECT * FROM customers ORDER BY created_at DESC");
            $customers = $stmt->fetchAll();
            sendResponse($customers);
        }
        break;

    case 'POST':
        $data = json_decode(file_get_contents('php://input'), true);
        $required = ['name', 'email', 'phone'];
        $missing = validateRequired($data, $required);
        
        if (!empty($missing)) {
            sendResponse(['error' => 'Missing required fields: ' . implode(', ', $missing)], 400);
        }

        try {
            $stmt = $pdo->prepare("INSERT INTO customers (name, email, phone, address) VALUES (?, ?, ?, ?)");
            $stmt->execute([
                $data['name'],
                $data['email'],
                $data['phone'],
                $data['address'] ?? null
            ]);
            
            $id = $pdo->lastInsertId();
            sendResponse(['id' => $id, 'message' => 'Customer created successfully'], 201);
        } catch (PDOException $e) {
            if ($e->getCode() == 23000) {
                sendResponse(['error' => 'Email already exists'], 409);
            } else {
                sendResponse(['error' => 'Database error: ' . $e->getMessage()], 500);
            }
        }
        break;

    case 'PUT':
        $data = json_decode(file_get_contents('php://input'), true);
        $required = ['id', 'name', 'email', 'phone'];
        $missing = validateRequired($data, $required);
        
        if (!empty($missing)) {
            sendResponse(['error' => 'Missing required fields: ' . implode(', ', $missing)], 400);
        }

        try {
            $stmt = $pdo->prepare("UPDATE customers SET name = ?, email = ?, phone = ?, address = ? WHERE id = ?");
            $result = $stmt->execute([
                $data['name'],
                $data['email'],
                $data['phone'],
                $data['address'] ?? null,
                $data['id']
            ]);
            
            if ($stmt->rowCount() > 0) {
                sendResponse(['message' => 'Customer updated successfully']);
            } else {
                sendResponse(['error' => 'Customer not found or no changes made'], 404);
            }
        } catch (PDOException $e) {
            if ($e->getCode() == 23000) {
                sendResponse(['error' => 'Email already exists'], 409);
            } else {
                sendResponse(['error' => 'Database error: ' . $e->getMessage()], 500);
            }
        }
        break;

    case 'DELETE':
        if (!isset($_GET['id'])) {
            sendResponse(['error' => 'Customer ID is required'], 400);
        }

        try {
            $stmt = $pdo->prepare("DELETE FROM customers WHERE id = ?");
            $stmt->execute([$_GET['id']]);
            
            if ($stmt->rowCount() > 0) {
                sendResponse(['message' => 'Customer deleted successfully']);
            } else {
                sendResponse(['error' => 'Customer not found'], 404);
            }
        } catch (PDOException $e) {
            sendResponse(['error' => 'Database error: ' . $e->getMessage()], 500);
        }
        break;

    default:
        sendResponse(['error' => 'Method not allowed'], 405);
}
?>
