<?php
require_once 'config.php';

$pdo = getDBConnection();
$method = $_SERVER['REQUEST_METHOD'];

switch ($method) {
    case 'GET':
        if (isset($_GET['id'])) {
            // Get single inventory item
            $stmt = $pdo->prepare("SELECT * FROM inventory WHERE id = ?");
            $stmt->execute([$_GET['id']]);
            $item = $stmt->fetch();
            
            if ($item) {
                sendResponse($item);
            } else {
                sendResponse(['error' => 'Inventory item not found'], 404);
            }
        } else {
            // Get all inventory items
            $stmt = $pdo->query("SELECT * FROM inventory ORDER BY category, item_name");
            $items = $stmt->fetchAll();
            sendResponse($items);
        }
        break;

    case 'POST':
        $data = json_decode(file_get_contents('php://input'), true);
        $required = ['item_name', 'category', 'current_stock', 'minimum_stock', 'unit'];
        $missing = validateRequired($data, $required);
        
        if (!empty($missing)) {
            sendResponse(['error' => 'Missing required fields: ' . implode(', ', $missing)], 400);
        }

        try {
            $stmt = $pdo->prepare("INSERT INTO inventory (item_name, category, current_stock, minimum_stock, unit, unit_cost, supplier, last_restocked) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
            $stmt->execute([
                $data['item_name'],
                $data['category'],
                $data['current_stock'],
                $data['minimum_stock'],
                $data['unit'],
                $data['unit_cost'] ?? null,
                $data['supplier'] ?? null,
                $data['last_restocked'] ?? null
            ]);
            
            $id = $pdo->lastInsertId();
            sendResponse(['id' => $id, 'message' => 'Inventory item created successfully'], 201);
        } catch (PDOException $e) {
            sendResponse(['error' => 'Database error: ' . $e->getMessage()], 500);
        }
        break;

    case 'PUT':
        $data = json_decode(file_get_contents('php://input'), true);
        
        // Handle restock action
        if (isset($data['action']) && $data['action'] === 'restock') {
            $required = ['id', 'quantity'];
            $missing = validateRequired($data, $required);
            
            if (!empty($missing)) {
                sendResponse(['error' => 'Missing required fields: ' . implode(', ', $missing)], 400);
            }

            try {
                $stmt = $pdo->prepare("UPDATE inventory SET current_stock = current_stock + ?, last_restocked = CURDATE() WHERE id = ?");
                $result = $stmt->execute([
                    $data['quantity'],
                    $data['id']
                ]);
                
                if ($stmt->rowCount() > 0) {
                    sendResponse(['message' => 'Item restocked successfully']);
                } else {
                    sendResponse(['error' => 'Inventory item not found'], 404);
                }
            } catch (PDOException $e) {
                sendResponse(['error' => 'Database error: ' . $e->getMessage()], 500);
            }
        } else {
            // Regular update
            $required = ['id', 'item_name', 'category', 'current_stock', 'minimum_stock', 'unit'];
            $missing = validateRequired($data, $required);
            
            if (!empty($missing)) {
                sendResponse(['error' => 'Missing required fields: ' . implode(', ', $missing)], 400);
            }

            try {
                $stmt = $pdo->prepare("UPDATE inventory SET item_name = ?, category = ?, current_stock = ?, minimum_stock = ?, unit = ?, unit_cost = ?, supplier = ?, last_restocked = ? WHERE id = ?");
                $result = $stmt->execute([
                    $data['item_name'],
                    $data['category'],
                    $data['current_stock'],
                    $data['minimum_stock'],
                    $data['unit'],
                    $data['unit_cost'] ?? null,
                    $data['supplier'] ?? null,
                    $data['last_restocked'] ?? null,
                    $data['id']
                ]);
                
                if ($stmt->rowCount() > 0) {
                    sendResponse(['message' => 'Inventory item updated successfully']);
                } else {
                    sendResponse(['error' => 'Inventory item not found or no changes made'], 404);
                }
            } catch (PDOException $e) {
                sendResponse(['error' => 'Database error: ' . $e->getMessage()], 500);
            }
        }
        break;

    case 'DELETE':
        if (!isset($_GET['id'])) {
            sendResponse(['error' => 'Inventory item ID is required'], 400);
        }

        try {
            $stmt = $pdo->prepare("DELETE FROM inventory WHERE id = ?");
            $stmt->execute([$_GET['id']]);
            
            if ($stmt->rowCount() > 0) {
                sendResponse(['message' => 'Inventory item deleted successfully']);
            } else {
                sendResponse(['error' => 'Inventory item not found'], 404);
            }
        } catch (PDOException $e) {
            sendResponse(['error' => 'Database error: ' . $e->getMessage()], 500);
        }
        break;

    default:
        sendResponse(['error' => 'Method not allowed'], 405);
}
?>
