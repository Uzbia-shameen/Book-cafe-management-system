<?php
require_once 'config.php';

$pdo = getDBConnection();
$method = $_SERVER['REQUEST_METHOD'];

switch ($method) {
    case 'GET':
        if (isset($_GET['id'])) {
            // Get single order item with menu item info
            $stmt = $pdo->prepare("
                SELECT oi.*, mi.name as menu_item_name 
                FROM order_items oi 
                JOIN menu_items mi ON oi.menu_item_id = mi.id 
                WHERE oi.id = ?
            ");
            $stmt->execute([$_GET['id']]);
            $orderItem = $stmt->fetch();
            
            if ($orderItem) {
                sendResponse($orderItem);
            } else {
                sendResponse(['error' => 'Order item not found'], 404);
            }
        } else {
            // Get all order items with menu item info
            $stmt = $pdo->query("
                SELECT oi.*, mi.name as menu_item_name 
                FROM order_items oi 
                JOIN menu_items mi ON oi.menu_item_id = mi.id 
                ORDER BY oi.created_at DESC
            ");
            $orderItems = $stmt->fetchAll();
            sendResponse($orderItems);
        }
        break;

    case 'POST':
        $data = json_decode(file_get_contents('php://input'), true);
        $required = ['order_id', 'menu_item_id', 'quantity', 'unit_price'];
        $missing = validateRequired($data, $required);
        
        if (!empty($missing)) {
            sendResponse(['error' => 'Missing required fields: ' . implode(', ', $missing)], 400);
        }

        try {
            $stmt = $pdo->prepare("INSERT INTO order_items (order_id, menu_item_id, quantity, unit_price) VALUES (?, ?, ?, ?)");
            $stmt->execute([
                $data['order_id'],
                $data['menu_item_id'],
                $data['quantity'],
                $data['unit_price']
            ]);
            
            $id = $pdo->lastInsertId();
            sendResponse(['id' => $id, 'message' => 'Order item created successfully'], 201);
        } catch (PDOException $e) {
            sendResponse(['error' => 'Database error: ' . $e->getMessage()], 500);
        }
        break;

    case 'PUT':
        $data = json_decode(file_get_contents('php://input'), true);
        $required = ['id', 'order_id', 'menu_item_id', 'quantity', 'unit_price'];
        $missing = validateRequired($data, $required);
        
        if (!empty($missing)) {
            sendResponse(['error' => 'Missing required fields: ' . implode(', ', $missing)], 400);
        }

        try {
            $stmt = $pdo->prepare("UPDATE order_items SET order_id = ?, menu_item_id = ?, quantity = ?, unit_price = ? WHERE id = ?");
            $result = $stmt->execute([
                $data['order_id'],
                $data['menu_item_id'],
                $data['quantity'],
                $data['unit_price'],
                $data['id']
            ]);
            
            if ($stmt->rowCount() > 0) {
                sendResponse(['message' => 'Order item updated successfully']);
            } else {
                sendResponse(['error' => 'Order item not found or no changes made'], 404);
            }
        } catch (PDOException $e) {
            sendResponse(['error' => 'Database error: ' . $e->getMessage()], 500);
        }
        break;

    case 'DELETE':
        if (!isset($_GET['id'])) {
            sendResponse(['error' => 'Order item ID is required'], 400);
        }

        try {
            $stmt = $pdo->prepare("DELETE FROM order_items WHERE id = ?");
            $stmt->execute([$_GET['id']]);
            
            if ($stmt->rowCount() > 0) {
                sendResponse(['message' => 'Order item deleted successfully']);
            } else {
                sendResponse(['error' => 'Order item not found'], 404);
            }
        } catch (PDOException $e) {
            sendResponse(['error' => 'Database error: ' . $e->getMessage()], 500);
        }
        break;

    default:
        sendResponse(['error' => 'Method not allowed'], 405);
}
?>
