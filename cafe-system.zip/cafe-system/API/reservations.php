<?php
require_once 'config.php';

$pdo = getDBConnection();
$method = $_SERVER['REQUEST_METHOD'];

switch ($method) {
    case 'GET':
        if (isset($_GET['id'])) {
            // Get single reservation with customer info
            $stmt = $pdo->prepare("
                SELECT r.*, c.name as customer_name 
                FROM reservations r 
                JOIN customers c ON r.customer_id = c.id 
                WHERE r.id = ?
            ");
            $stmt->execute([$_GET['id']]);
            $reservation = $stmt->fetch();
            
            if ($reservation) {
                sendResponse($reservation);
            } else {
                sendResponse(['error' => 'Reservation not found'], 404);
            }
        } else {
            // Get all reservations with customer info
            $stmt = $pdo->query("
                SELECT r.*, c.name as customer_name 
                FROM reservations r 
                JOIN customers c ON r.customer_id = c.id 
                ORDER BY r.reservation_date DESC, r.reservation_time DESC
            ");
            $reservations = $stmt->fetchAll();
            sendResponse($reservations);
        }
        break;

    case 'POST':
        $data = json_decode(file_get_contents('php://input'), true);
        $required = ['customer_id', 'reservation_date', 'reservation_time', 'party_size', 'status'];
        $missing = validateRequired($data, $required);
        
        if (!empty($missing)) {
            sendResponse(['error' => 'Missing required fields: ' . implode(', ', $missing)], 400);
        }

        try {
            $stmt = $pdo->prepare("INSERT INTO reservations (customer_id, reservation_date, reservation_time, party_size, status, special_requests) VALUES (?, ?, ?, ?, ?, ?)");
            $stmt->execute([
                $data['customer_id'],
                $data['reservation_date'],
                $data['reservation_time'],
                $data['party_size'],
                $data['status'],
                $data['special_requests'] ?? null
            ]);
            
            $id = $pdo->lastInsertId();
            sendResponse(['id' => $id, 'message' => 'Reservation created successfully'], 201);
        } catch (PDOException $e) {
            sendResponse(['error' => 'Database error: ' . $e->getMessage()], 500);
        }
        break;

    case 'PUT':
        $data = json_decode(file_get_contents('php://input'), true);
        $required = ['id', 'customer_id', 'reservation_date', 'reservation_time', 'party_size', 'status'];
        $missing = validateRequired($data, $required);
        
        if (!empty($missing)) {
            sendResponse(['error' => 'Missing required fields: ' . implode(', ', $missing)], 400);
        }

        try {
            $stmt = $pdo->prepare("UPDATE reservations SET customer_id = ?, reservation_date = ?, reservation_time = ?, party_size = ?, status = ?, special_requests = ? WHERE id = ?");
            $result = $stmt->execute([
                $data['customer_id'],
                $data['reservation_date'],
                $data['reservation_time'],
                $data['party_size'],
                $data['status'],
                $data['special_requests'] ?? null,
                $data['id']
            ]);
            
            if ($stmt->rowCount() > 0) {
                sendResponse(['message' => 'Reservation updated successfully']);
            } else {
                sendResponse(['error' => 'Reservation not found or no changes made'], 404);
            }
        } catch (PDOException $e) {
            sendResponse(['error' => 'Database error: ' . $e->getMessage()], 500);
        }
        break;

    case 'DELETE':
        if (!isset($_GET['id'])) {
            sendResponse(['error' => 'Reservation ID is required'], 400);
        }

        try {
            $stmt = $pdo->prepare("DELETE FROM reservations WHERE id = ?");
            $stmt->execute([$_GET['id']]);
            
            if ($stmt->rowCount() > 0) {
                sendResponse(['message' => 'Reservation deleted successfully']);
            } else {
                sendResponse(['error' => 'Reservation not found'], 404);
            }
        } catch (PDOException $e) {
            sendResponse(['error' => 'Database error: ' . $e->getMessage()], 500);
        }
        break;

    default:
        sendResponse(['error' => 'Method not allowed'], 405);
}
?>
