<?php
require_once 'config.php';

$pdo = getDBConnection();
$method = $_SERVER['REQUEST_METHOD'];

switch ($method) {
    case 'GET':
        if (isset($_GET['id'])) {
            // Get single order with customer info
            $stmt = $pdo->prepare("
                SELECT o.*, c.name as customer_name 
                FROM orders o 
                JOIN customers c ON o.customer_id = c.id 
                WHERE o.id = ?
            ");
            $stmt->execute([$_GET['id']]);
            $order = $stmt->fetch();
            
            if ($order) {
                sendResponse($order);
            } else {
                sendResponse(['error' => 'Order not found'], 404);
            }
        } else {
            // Get all orders with customer info
            $stmt = $pdo->query("
                SELECT o.*, c.name as customer_name 
                FROM orders o 
                JOIN customers c ON o.customer_id = c.id 
                ORDER BY o.order_date DESC
            ");
            $orders = $stmt->fetchAll();
            sendResponse($orders);
        }
        break;

    case 'POST':
        $data = json_decode(file_get_contents('php://input'), true);
        $required = ['customer_id', 'order_date', 'total_amount', 'status'];
        $missing = validateRequired($data, $required);
        
        if (!empty($missing)) {
            sendResponse(['error' => 'Missing required fields: ' . implode(', ', $missing)], 400);
        }

        try {
            $stmt = $pdo->prepare("INSERT INTO orders (customer_id, order_date, total_amount, status) VALUES (?, ?, ?, ?)");
            $stmt->execute([
                $data['customer_id'],
                $data['order_date'],
                $data['total_amount'],
                $data['status']
            ]);
            
            $id = $pdo->lastInsertId();
            sendResponse(['id' => $id, 'message' => 'Order created successfully'], 201);
        } catch (PDOException $e) {
            sendResponse(['error' => 'Database error: ' . $e->getMessage()], 500);
        }
        break;

    case 'PUT':
        $data = json_decode(file_get_contents('php://input'), true);
        $required = ['id', 'customer_id', 'order_date', 'total_amount', 'status'];
        $missing = validateRequired($data, $required);
        
        if (!empty($missing)) {
            sendResponse(['error' => 'Missing required fields: ' . implode(', ', $missing)], 400);
        }

        try {
            $stmt = $pdo->prepare("UPDATE orders SET customer_id = ?, order_date = ?, total_amount = ?, status = ? WHERE id = ?");
            $result = $stmt->execute([
                $data['customer_id'],
                $data['order_date'],
                $data['total_amount'],
                $data['status'],
                $data['id']
            ]);
            
            if ($stmt->rowCount() > 0) {
                sendResponse(['message' => 'Order updated successfully']);
            } else {
                sendResponse(['error' => 'Order not found or no changes made'], 404);
            }
        } catch (PDOException $e) {
            sendResponse(['error' => 'Database error: ' . $e->getMessage()], 500);
        }
        break;

    case 'DELETE':
        if (!isset($_GET['id'])) {
            sendResponse(['error' => 'Order ID is required'], 400);
        }

        try {
            $stmt = $pdo->prepare("DELETE FROM orders WHERE id = ?");
            $stmt->execute([$_GET['id']]);
            
            if ($stmt->rowCount() > 0) {
                sendResponse(['message' => 'Order deleted successfully']);
            } else {
                sendResponse(['error' => 'Order not found'], 404);
            }
        } catch (PDOException $e) {
            sendResponse(['error' => 'Database error: ' . $e->getMessage()], 500);
        }
        break;

    default:
        sendResponse(['error' => 'Method not allowed'], 405);
}
?>
