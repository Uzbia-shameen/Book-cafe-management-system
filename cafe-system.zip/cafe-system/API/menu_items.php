<?php
require_once 'config.php';

$pdo = getDBConnection();
$method = $_SERVER['REQUEST_METHOD'];

switch ($method) {
    case 'GET':
        if (isset($_GET['id'])) {
            // Get single menu item
            $stmt = $pdo->prepare("SELECT * FROM menu_items WHERE id = ?");
            $stmt->execute([$_GET['id']]);
            $item = $stmt->fetch();
            
            if ($item) {
                sendResponse($item);
            } else {
                sendResponse(['error' => 'Menu item not found'], 404);
            }
        } else {
            // Get all menu items
            $stmt = $pdo->query("SELECT * FROM menu_items ORDER BY category, name");
            $items = $stmt->fetchAll();
            sendResponse($items);
        }
        break;

    case 'POST':
        $data = json_decode(file_get_contents('php://input'), true);
        $required = ['name', 'category', 'price'];
        $missing = validateRequired($data, $required);
        
        if (!empty($missing)) {
            sendResponse(['error' => 'Missing required fields: ' . implode(', ', $missing)], 400);
        }

        try {
            $stmt = $pdo->prepare("INSERT INTO menu_items (name, category, price, description, is_available) VALUES (?, ?, ?, ?, ?)");
            $stmt->execute([
                $data['name'],
                $data['category'],
                $data['price'],
                $data['description'] ?? null,
                $data['is_available'] ?? 1
            ]);
            
            $id = $pdo->lastInsertId();
            sendResponse(['id' => $id, 'message' => 'Menu item created successfully'], 201);
        } catch (PDOException $e) {
            sendResponse(['error' => 'Database error: ' . $e->getMessage()], 500);
        }
        break;

    case 'PUT':
        $data = json_decode(file_get_contents('php://input'), true);
        $required = ['id', 'name', 'category', 'price'];
        $missing = validateRequired($data, $required);
        
        if (!empty($missing)) {
            sendResponse(['error' => 'Missing required fields: ' . implode(', ', $missing)], 400);
        }

        try {
            $stmt = $pdo->prepare("UPDATE menu_items SET name = ?, category = ?, price = ?, description = ?, is_available = ? WHERE id = ?");
            $result = $stmt->execute([
                $data['name'],
                $data['category'],
                $data['price'],
                $data['description'] ?? null,
                $data['is_available'] ?? 1,
                $data['id']
            ]);
            
            if ($stmt->rowCount() > 0) {
                sendResponse(['message' => 'Menu item updated successfully']);
            } else {
                sendResponse(['error' => 'Menu item not found or no changes made'], 404);
            }
        } catch (PDOException $e) {
            sendResponse(['error' => 'Database error: ' . $e->getMessage()], 500);
        }
        break;

    case 'DELETE':
        if (!isset($_GET['id'])) {
            sendResponse(['error' => 'Menu item ID is required'], 400);
        }

        try {
            $stmt = $pdo->prepare("DELETE FROM menu_items WHERE id = ?");
            $stmt->execute([$_GET['id']]);
            
            if ($stmt->rowCount() > 0) {
                sendResponse(['message' => 'Menu item deleted successfully']);
            } else {
                sendResponse(['error' => 'Menu item not found'], 404);
            }
        } catch (PDOException $e) {
            sendResponse(['error' => 'Database error: ' . $e->getMessage()], 500);
        }
        break;

    default:
        sendResponse(['error' => 'Method not allowed'], 405);
}
?>
