
<?php
require_once 'config.php';

$pdo = getDBConnection();
$method = $_SERVER['REQUEST_METHOD'];

switch ($method) {
    case 'GET':
        if (isset($_GET['id'])) {
            // Get single book
            $stmt = $pdo->prepare("SELECT * FROM books WHERE id = ?");
            $stmt->execute([$_GET['id']]);
            $book = $stmt->fetch();
            
            if ($book) {
                sendResponse($book);
            } else {
                sendResponse(['error' => 'Book not found'], 404);
            }
        } else {
            // Get all books
            $stmt = $pdo->query("SELECT * FROM books ORDER BY title");
            $books = $stmt->fetchAll();
            sendResponse($books);
        }
        break;

    case 'POST':
        $data = json_decode(file_get_contents('php://input'), true);
        $required = ['title', 'author', 'genre', 'status'];
        $missing = validateRequired($data, $required);
        
        if (!empty($missing)) {
            sendResponse(['error' => 'Missing required fields: ' . implode(', ', $missing)], 400);
        }

        try {
            $stmt = $pdo->prepare("INSERT INTO books (title, author, isbn, genre, status, condition_notes) VALUES (?, ?, ?, ?, ?, ?)");
            $stmt->execute([
                $data['title'],
                $data['author'],
                $data['isbn'] ?? null,
                $data['genre'],
                $data['status'],
                $data['condition_notes'] ?? null
            ]);
            
            $id = $pdo->lastInsertId();
            sendResponse(['id' => $id, 'message' => 'Book created successfully'], 201);
        } catch (PDOException $e) {
            sendResponse(['error' => 'Database error: ' . $e->getMessage()], 500);
        }
        break;

    case 'PUT':
        $data = json_decode(file_get_contents('php://input'), true);
        $required = ['id', 'title', 'author', 'genre', 'status'];
        $missing = validateRequired($data, $required);
        
        if (!empty($missing)) {
            sendResponse(['error' => 'Missing required fields: ' . implode(', ', $missing)], 400);
        }

        try {
            $stmt = $pdo->prepare("UPDATE books SET title = ?, author = ?, isbn = ?, genre = ?, status = ?, condition_notes = ? WHERE id = ?");
            $result = $stmt->execute([
                $data['title'],
                $data['author'],
                $data['isbn'] ?? null,
                $data['genre'],
                $data['status'],
                $data['condition_notes'] ?? null,
                $data['id']
            ]);
            
            if ($stmt->rowCount() > 0) {
                sendResponse(['message' => 'Book updated successfully']);
            } else {
                sendResponse(['error' => 'Book not found or no changes made'], 404);
            }
        } catch (PDOException $e) {
            sendResponse(['error' => 'Database error: ' . $e->getMessage()], 500);
        }
        break;

    case 'DELETE':
        if (!isset($_GET['id'])) {
            sendResponse(['error' => 'Book ID is required'], 400);
        }

        try {
            $stmt = $pdo->prepare("DELETE FROM books WHERE id = ?");
            $stmt->execute([$_GET['id']]);
            
            if ($stmt->rowCount() > 0) {
                sendResponse(['message' => 'Book deleted successfully']);
            } else {
                sendResponse(['error' => 'Book not found'], 404);
            }
        } catch (PDOException $e) {
            sendResponse(['error' => 'Database error: ' . $e->getMessage()], 500);
        }
        break;

    default:
        sendResponse(['error' => 'Method not allowed'], 405);
}
?>
