<?php
require_once 'config.php';

$pdo = getDBConnection();

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    sendResponse(['error' => 'Method not allowed'], 405);
}

$type = $_GET['type'] ?? '';
$id = $_GET['id'] ?? '';

if (empty($type) || empty($id)) {
    sendResponse(['error' => 'Type and ID are required'], 400);
}

try {
    switch ($type) {
        case 'order':
            // Get order receipt with items
            $stmt = $pdo->prepare("
                SELECT 
                    o.id,
                    o.order_date as date,
                    o.total_amount,
                    c.name as customer_name,
                    c.email as customer_email,
                    c.phone as customer_phone
                FROM orders o
                JOIN customers c ON o.customer_id = c.id
                WHERE o.id = ?
            ");
            $stmt->execute([$id]);
            $receipt = $stmt->fetch();
            
            if (!$receipt) {
                sendResponse(['error' => 'Order not found'], 404);
            }
            
            // Get order items
            $stmt = $pdo->prepare("
                SELECT 
                    oi.quantity,
                    oi.unit_price as price,
                    mi.name
                FROM order_items oi
                JOIN menu_items mi ON oi.menu_item_id = mi.id
                WHERE oi.order_id = ?
            ");
            $stmt->execute([$id]);
            $receipt['items'] = $stmt->fetchAll();
            $receipt['order_id'] = $receipt['id'];
            
            sendResponse($receipt);
            break;
            
        case 'payment':
            // Get payment receipt
            $stmt = $pdo->prepare("
                SELECT 
                    p.id,
                    p.payment_date as date,
                    p.amount as total_amount,
                    p.payment_method,
                    p.order_id,
                    c.name as customer_name,
                    c.email as customer_email,
                    c.phone as customer_phone
                FROM payments p
                JOIN orders o ON p.order_id = o.id
                JOIN customers c ON o.customer_id = c.id
                WHERE p.id = ?
            ");
            $stmt->execute([$id]);
            $receipt = $stmt->fetch();
            
            if (!$receipt) {
                sendResponse(['error' => 'Payment not found'], 404);
            }
            
            sendResponse($receipt);
            break;
            
        case 'reservation':
            // Get reservation receipt
            $stmt = $pdo->prepare("
                SELECT 
                    r.id,
                    r.reservation_date as date,
                    r.reservation_time,
                    r.party_size,
                    r.status,
                    r.special_requests,
                    c.name as customer_name,
                    c.email as customer_email,
                    c.phone as customer_phone
                FROM reservations r
                JOIN customers c ON r.customer_id = c.id
                WHERE r.id = ?
            ");
            $stmt->execute([$id]);
            $receipt = $stmt->fetch();
            
            if (!$receipt) {
                sendResponse(['error' => 'Reservation not found'], 404);
            }
            
            $receipt['total_amount'] = 0; // Reservations don't have amounts
            sendResponse($receipt);
            break;
            
        case 'customer':
            // Get customer summary receipt
            $stmt = $pdo->prepare("
                SELECT 
                    c.id,
                    c.name as customer_name,
                    c.email as customer_email,
                    c.phone as customer_phone,
                    c.created_at as date,
                    COUNT(o.id) as total_orders,
                    COALESCE(SUM(o.total_amount), 0) as total_spent
                FROM customers c
                LEFT JOIN orders o ON c.id = o.customer_id
                WHERE c.id = ?
                GROUP BY c.id
            ");
            $stmt->execute([$id]);
            $receipt = $stmt->fetch();
            
            if (!$receipt) {
                sendResponse(['error' => 'Customer not found'], 404);
            }
            
            $receipt['total_amount'] = $receipt['total_spent'];
            sendResponse($receipt);
            break;
            
        default:
            sendResponse(['error' => 'Invalid receipt type'], 400);
    }
} catch (PDOException $e) {
    sendResponse(['error' => 'Database error: ' . $e->getMessage()], 500);
}
?>
